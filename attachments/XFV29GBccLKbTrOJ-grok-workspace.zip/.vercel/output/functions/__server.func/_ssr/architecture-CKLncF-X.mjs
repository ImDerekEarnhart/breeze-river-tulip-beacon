import { i as __toESM } from "../_runtime.mjs";
import { B as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as NODE_COPY, t as ArchitectureMap } from "./architecture-map-CmiWTv95.mjs";
import { t as Badge } from "./badge-w3Tfyg13.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/architecture-CKLncF-X.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var PHASES = [
	{
		n: "01",
		title: "Worker loop",
		body: "GPU VM, vLLM student, orchestrator, a handful of tools. One agent that can finish a structured task."
	},
	{
		n: "02",
		title: "Language tower",
		body: "Embedding, vector search, rerank. Stop spending generator tokens on memory."
	},
	{
		n: "03",
		title: "Teacher routing",
		body: "Student first. Escalate on low confidence or failed verify. Collect traces."
	},
	{
		n: "04",
		title: "Orbita",
		body: "Teacher proposes. Plan is hashed. Approval boundary. Discovery. Independent evaluation."
	},
	{
		n: "05",
		title: "Improve the worker",
		body: "Failures → teacher → falsification → training set → LoRA. The worker never rewrites itself."
	},
	{
		n: "06",
		title: "PocketDesktop",
		body: "A private XFCE target with a narrow API. Screenshots, pointer, keys, allow-listed apps. Never sudo."
	}
];
function ArchitectureView() {
	const [selected, setSelected] = (0, import_react.useState)("orchestrator");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-4 py-6 md:px-8 md:py-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "max-w-3xl",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-[10px] uppercase tracking-[0.18em] text-subtle",
						children: "System"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-2 font-display text-3xl tracking-tight md:text-4xl",
						children: "Not a model with a shell attached."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 max-w-2xl text-sm leading-relaxed text-muted md:text-base",
						children: "Inference, retrieval, governance, and execution are separate. The agent is the loop that binds them. Click a layer."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArchitectureMap, {
					selected,
					onSelect: setSelected
				})
			}),
			selected && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 max-w-2xl rounded-[var(--radius-lg)] border border-border bg-bg-elevated px-5 py-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "font-mono text-[10px] uppercase tracking-[0.16em] text-subtle",
					children: selected
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm leading-relaxed text-fg",
					children: NODE_COPY[selected]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-12",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl tracking-tight",
					children: "Two loops"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 grid gap-4 md:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "rounded-[var(--radius-xl)] border border-border bg-bg-elevated p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: "student",
								children: "Fast"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-3 text-lg text-fg",
								children: "Milliseconds to seconds"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm leading-relaxed text-muted",
								children: "User → retrieve → student → tool → verify → answer. The worker stays cheap. Tools never share a process with the model."
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "rounded-[var(--radius-xl)] border border-border bg-bg-elevated p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: "teacher",
								children: "Governed"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-3 text-lg text-fg",
								children: "When the claim matters"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm leading-relaxed text-muted",
								children: "Case → teacher plan → SHA-256 freeze → approval → discovery → sandbox → independent evaluation. A proposal is not a result."
							})
						]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-12 pb-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl tracking-tight",
					children: "Build order"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-4 grid gap-3",
					children: PHASES.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "grid grid-cols-[auto_1fr] gap-4 rounded-[var(--radius-md)] border border-border px-4 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-xs text-subtle",
							children: p.n
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-sm text-fg",
							children: p.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted",
							children: p.body
						})] })]
					}, p.n))
				})]
			})
		]
	});
}
function ArchitecturePage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArchitectureView, {});
}
//#endregion
export { ArchitecturePage as component };
