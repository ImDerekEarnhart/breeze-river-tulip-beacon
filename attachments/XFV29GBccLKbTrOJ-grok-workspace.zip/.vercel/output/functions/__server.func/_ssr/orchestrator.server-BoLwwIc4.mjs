import { i as initialDesktop, r as applyDesk } from "./desktop-DqRBeHU8.mjs";
import { t as CORPUS } from "./corpus-BiGCh9Bd.mjs";
import { createHash } from "node:crypto";
import { spawn } from "node:child_process";
//#region node_modules/.nitro/vite/services/ssr/assets/orchestrator.server-BoLwwIc4.js
var STOP = /* @__PURE__ */ new Set([
	"the",
	"a",
	"an",
	"and",
	"or",
	"to",
	"of",
	"in",
	"on",
	"for",
	"is",
	"it",
	"as",
	"be",
	"by",
	"with",
	"that",
	"this",
	"from",
	"are",
	"was",
	"at",
	"not",
	"into",
	"than",
	"then",
	"its"
]);
function tokenize(text) {
	return text.toLowerCase().replace(/[^a-z0-9\s/+.-]/g, " ").split(/\s+/).filter((t) => t.length > 1 && !STOP.has(t));
}
var DOC_TOKENS = CORPUS.map((d) => tokenize(`${d.title} ${d.tags.join(" ")} ${d.text}`));
var DF = /* @__PURE__ */ new Map();
for (const tokens of DOC_TOKENS) for (const t of new Set(tokens)) DF.set(t, (DF.get(t) ?? 0) + 1);
var N = CORPUS.length;
var K1 = 1.4;
var B = .75;
var AVG_LEN = DOC_TOKENS.reduce((s, t) => s + t.length, 0) / N;
function bm25(query, docIndex) {
	const tokens = DOC_TOKENS[docIndex] ?? [];
	const tf = /* @__PURE__ */ new Map();
	for (const t of tokens) tf.set(t, (tf.get(t) ?? 0) + 1);
	const dl = tokens.length || 1;
	let score = 0;
	for (const q of query) {
		const f = tf.get(q) ?? 0;
		if (!f) continue;
		const df = DF.get(q) ?? .5;
		const idf = Math.log(1 + (N - df + .5) / (df + .5));
		const denom = f + K1 * (.25 + B * (dl / AVG_LEN));
		score += idf * (f * 2.4 / denom);
	}
	return score;
}
function rerank(query, docs) {
	const q = tokenize(query);
	return docs.map((d) => {
		const titleHits = tokenize(d.title).filter((t) => q.includes(t)).length;
		const tagHits = d.tags.filter((t) => q.includes(t.toLowerCase())).length;
		return {
			...d,
			score: d.score + titleHits * 1.8 + tagHits * 1.1
		};
	}).sort((a, b) => b.score - a.score);
}
function retrieve(query, limit = 5) {
	const q = tokenize(query);
	if (q.length === 0) return [];
	return rerank(query, CORPUS.map((doc, i) => ({
		id: doc.id,
		title: doc.title,
		text: doc.text,
		tags: doc.tags,
		score: bm25(q, i)
	})).filter((d) => d.score > 0).sort((a, b) => b.score - a.score).slice(0, 12)).slice(0, limit);
}
function corpusStats() {
	return {
		documents: CORPUS.length,
		tokens: DOC_TOKENS.reduce((s, t) => s + t.length, 0),
		tags: [...new Set(CORPUS.flatMap((d) => d.tags))].length
	};
}
var BANNED = /\b(os|sys|subprocess|socket|pathlib|shutil|requests|http|urllib|ctypes|multiprocessing|pty|fcntl|importlib|builtins|eval|exec|open|compile|__import__|globals|locals|input|file|breakpoint)\b/i;
function looksDangerous(code) {
	if (code.length > 3500) return "Code exceeds sandbox limit.";
	if (BANNED.test(code)) return "Policy engine blocked a disallowed name.";
	if (/[\\/]etc[\\/]|[\\/]proc[\\/]|[\\/]sys[\\/]/.test(code)) return "Policy engine blocked a filesystem path.";
	return null;
}
function runPythonProcess(code) {
	return new Promise((resolve) => {
		const child = spawn("python3", [
			"-I",
			"-c",
			"import sys; exec(sys.stdin.read(), {'__name__':'__sandbox__'})"
		], {
			timeout: 2500,
			env: {
				PATH: "/usr/bin:/bin",
				LANG: "C.UTF-8"
			},
			stdio: [
				"pipe",
				"pipe",
				"pipe"
			]
		});
		let out = "";
		let err = "";
		child.stdout.on("data", (d) => {
			out += d.toString();
		});
		child.stderr.on("data", (d) => {
			err += d.toString();
		});
		child.on("error", (e) => {
			resolve({
				ok: false,
				output: e.message
			});
		});
		child.on("close", (codeExit) => {
			const text = `${out}${err ? (out ? "\n" : "") + err : ""}`.trim();
			resolve({
				ok: codeExit === 0,
				output: (text || `(exit ${codeExit})`).slice(0, 6e3)
			});
		});
		child.stdin.write(code);
		child.stdin.end();
	});
}
function jsMathFallback(code) {
	const expr = code.replace(/print\((.*)\)/gs, "$1").replace(/\*\*/g, "^").trim();
	if (!/^[0-9+\-*/^().,\s]+$/.test(expr.replace(/\^/g, "**"))) return {
		ok: false,
		output: "Sandbox worker unavailable; only arithmetic could be evaluated locally."
	};
	try {
		const js = expr.replace(/\^/g, "**");
		const value = Function(`"use strict"; return (${js});`)();
		return {
			ok: true,
			output: String(value)
		};
	} catch (e) {
		return {
			ok: false,
			output: e instanceof Error ? e.message : "eval failed"
		};
	}
}
async function runSandbox(code) {
	const blocked = looksDangerous(code);
	if (blocked) return {
		ok: false,
		output: blocked
	};
	try {
		const result = await runPythonProcess(code);
		if (result.ok || result.output) return result;
	} catch {}
	return jsMathFallback(code);
}
var TOOL_SCHEMAS = [
	{
		name: "sandbox",
		description: "Run short Python in an isolated worker. Use for arithmetic, lists, and numeric checks. No files, no network, no OS.",
		arguments: { code: "python source" }
	},
	{
		name: "retrieve",
		description: "Search the language tower / semantic memory for more passages.",
		arguments: { query: "search query" }
	},
	{
		name: "memory_read",
		description: "Read a working or episodic memory item by id or keyword.",
		arguments: { query: "id or keyword" }
	},
	{
		name: "memory_write",
		description: "Write a short note into working memory for this run.",
		arguments: {
			title: "title",
			body: "body"
		}
	},
	{
		name: "orbita_status",
		description: "Inspect current governed-experiment primitives and frozen-plan rules.",
		arguments: { topic: "optional focus" }
	},
	{
		name: "desktop",
		description: "PocketDesktop narrow API. action=status|start|stop|screenshot|click|type|launch. Approved apps: chromium, files, terminal, calculator. No root, no sudo, no ssh.",
		arguments: {
			action: "status|start|stop|screenshot|click|type|launch",
			x: "px",
			y: "px",
			text: "keys",
			app: "allow-listed app"
		}
	}
];
var ALLOWED = new Set(TOOL_SCHEMAS.map((t) => t.name));
async function executeTool(call, memory, desk = initialDesktop()) {
	if (!ALLOWED.has(call.name)) return {
		result: {
			name: call.name,
			ok: false,
			output: "ToolDenied: not in ALLOWED_TOOLS"
		},
		desk
	};
	if (call.name === "sandbox") {
		const code = call.arguments.code ?? call.arguments.source ?? "";
		if (!code.trim()) return {
			result: {
				name: "sandbox",
				ok: false,
				output: "Missing code"
			},
			desk
		};
		const ran = await runSandbox(code);
		return {
			result: {
				name: "sandbox",
				ok: ran.ok,
				output: ran.output
			},
			desk
		};
	}
	if (call.name === "retrieve") return {
		result: {
			name: "retrieve",
			ok: true,
			output: retrieve(call.arguments.query ?? "", 4).map((d) => `[${d.id}] ${d.title}\n${d.text.slice(0, 420)}`).join("\n\n")
		},
		desk
	};
	if (call.name === "memory_read") {
		const q = (call.arguments.query ?? "").toLowerCase();
		const hits = memory.filter((m) => m.id.includes(q) || m.title.toLowerCase().includes(q) || m.body.toLowerCase().includes(q) || m.kind.includes(q));
		return {
			result: {
				name: "memory_read",
				ok: true,
				output: hits.length ? hits.slice(0, 6).map((m) => `[${m.kind}/${m.id}] ${m.title}: ${m.body}`).join("\n") : "No matching memory."
			},
			desk
		};
	}
	if (call.name === "memory_write") return {
		result: {
			name: "memory_write",
			ok: true,
			output: `stored:${call.arguments.title ?? "note"}`
		},
		desk
	};
	if (call.name === "orbita_status") return {
		result: {
			name: "orbita_status",
			ok: true,
			output: "Primitives: case_context, compile_plan, submit_plan, get_plan, approve_plan, run_discovery, freeze_external_experiment, record_evaluation. Frozen plans are SHA-256 hashed and immutable. Ordinary chat should not enter this path."
		},
		desk
	};
	if (call.name === "desktop") {
		const action = (call.arguments.action ?? "status").toLowerCase();
		let current = desk;
		const notes = [];
		if (current.status !== "running" && (action === "screenshot" || action === "click" || action === "type" || action === "launch")) {
			const booted = applyDesk(current, { action: "start" });
			current = booted.snapshot;
			notes.push(booted.output.split("\n")[0] ?? "started");
		}
		const applied = applyDesk(current, {
			action,
			x: call.arguments.x ? Number(call.arguments.x) : void 0,
			y: call.arguments.y ? Number(call.arguments.y) : void 0,
			text: call.arguments.text,
			app: call.arguments.app
		});
		const output = notes.length ? `${notes.join("\n")}\n${applied.output}` : applied.output;
		return {
			result: {
				name: "desktop",
				ok: applied.ok,
				output
			},
			desk: applied.snapshot
		};
	}
	return {
		result: {
			name: call.name,
			ok: false,
			output: "Unknown tool"
		},
		desk
	};
}
var STUDENT_MODEL = "grok-4.5";
var TEACHER_MODEL = "grok-4.5";
var FALLBACK_MODELS = [
	"grok-4.5",
	"grok-4.6",
	"grok-4"
];
function aiAvailable() {
	return Boolean(process.env.XAI_API_KEY);
}
async function postChat(model, messages, opts) {
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return {
		ok: false,
		error: "AI is not available in this environment"
	};
	const body = {
		model,
		messages,
		max_tokens: opts.maxTokens,
		temperature: opts.temperature
	};
	if (opts.json) body.response_format = { type: "json_object" };
	const res = await fetch("https://api.x.ai/v1/chat/completions", {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			Authorization: `Bearer ${apiKey}`
		},
		body: JSON.stringify(body)
	});
	if (!res.ok) {
		const errText = await res.text().catch(() => "");
		return {
			ok: false,
			error: `xAI API error ${res.status}${errText ? `: ${errText.slice(0, 180)}` : ""}`
		};
	}
	const data = await res.json();
	return {
		ok: true,
		text: data.choices?.[0]?.message?.content ?? "",
		model: data.model ?? model
	};
}
async function chatWithFallback(preferred, messages, opts) {
	const models = [preferred, ...FALLBACK_MODELS.filter((m) => m !== preferred)];
	let last = {
		ok: false,
		error: "No model attempted"
	};
	for (const model of models) {
		last = await postChat(model, messages, opts);
		if (last.ok) return last;
		if (!/404|400|model/.test(last.error)) return last;
	}
	return last;
}
function studentChat(messages, opts) {
	return chatWithFallback(STUDENT_MODEL, messages, {
		maxTokens: opts?.maxTokens ?? 500,
		temperature: .2,
		json: true
	});
}
function teacherChat(messages, opts) {
	return chatWithFallback(TEACHER_MODEL, messages, {
		maxTokens: opts?.maxTokens ?? 900,
		temperature: .3,
		json: opts?.json ?? true
	});
}
function sha256(text) {
	return createHash("sha256").update(text).digest("hex");
}
function compilePlan(question, plan) {
	const trimmed = plan.trim();
	const planHash = sha256(trimmed);
	return {
		caseId: `case-${planHash.slice(0, 8)}`,
		question,
		plan: trimmed,
		planHash,
		status: "frozen",
		createdAt: Date.now()
	};
}
function approvePlan(record) {
	return {
		...record,
		status: "approved"
	};
}
function attachDiscovery(record, discovery) {
	return {
		...record,
		status: "discovery",
		discovery
	};
}
function evaluateRecord(record, evaluation) {
	return {
		...record,
		status: "evaluated",
		evaluation
	};
}
function step(kind, title, detail, extra) {
	return {
		id: crypto.randomUUID().slice(0, 8),
		kind,
		title,
		detail,
		latencyMs: extra?.latencyMs ?? 0,
		model: extra?.model,
		data: extra?.data
	};
}
function parseDecision(raw) {
	const trimmed = raw.trim();
	const start = trimmed.indexOf("{");
	const end = trimmed.lastIndexOf("}");
	if (start < 0 || end <= start) return null;
	try {
		const obj = JSON.parse(trimmed.slice(start, end + 1));
		const action = obj.action === "tool" || obj.action === "escalate" || obj.action === "answer" ? obj.action : "answer";
		const toolRaw = obj.tool;
		let tool;
		if (toolRaw?.name) {
			const args = {};
			if (toolRaw.arguments && typeof toolRaw.arguments === "object") for (const [k, v] of Object.entries(toolRaw.arguments)) args[k] = typeof v === "string" ? v : JSON.stringify(v);
			tool = {
				name: toolRaw.name,
				arguments: args
			};
		}
		return {
			thought: String(obj.thought ?? ""),
			confidence: Math.max(0, Math.min(1, Number(obj.confidence ?? .5))),
			action,
			tool,
			answer: obj.answer ? String(obj.answer) : void 0,
			citations: Array.isArray(obj.citations) ? obj.citations.map((c) => String(c)) : void 0
		};
	} catch {
		return null;
	}
}
var STUDENT_SYS = `You are Orbita's worker SLM. Handle ordinary tasks: classify, retrieve, extract, tool use, simple coding, short answers.
Respond ONLY as JSON:
{
  "thought": "short",
  "confidence": 0.0-1.0,
  "action": "answer" | "tool" | "escalate",
  "tool": { "name": "sandbox"|"retrieve"|"memory_read"|"memory_write"|"orbita_status"|"desktop", "arguments": { } },
  "answer": "final answer if action=answer",
  "citations": ["doc-id"]
}
Tools: ${TOOL_SCHEMAS.map((t) => `${t.name}: ${t.description}`).join(" | ")}
Rules:
- Use sandbox for numeric work. Python only, no files/network.
- PocketDesktop is screenshot/click/type/launch only. Never sudo or ssh.
- Cite retrieved doc ids when you used them.
- Escalate if confidence < 0.55, the task is experimental design, or you cannot verify.
- Keep answers tight and specific. No markdown tables.`;
var TEACHER_SYS = `You are Orbita's teacher LLM. You handle difficult reasoning, supervision, verification, and governed experiment plans.
Respond ONLY as JSON with keys thought, confidence, action, answer, citations, and optionally plan, discovery, evaluation_pass, evaluation_notes.
If asked to propose a governed plan, put the full frozen-ready plan in "plan" with Hypothesis, Method, Success, Falsification, Sandbox steps.
If asked to evaluate, set evaluation_pass boolean and evaluation_notes.
Be precise. Prefer falsifiable statements.`;
function docsBlock(docs) {
	if (!docs.length) return "No retrieved passages.";
	return docs.map((d) => `[${d.id}] ${d.title} (score ${d.score.toFixed(2)})\n${d.text.slice(0, 700)}`).join("\n\n");
}
function verify(request, decision, tools) {
	if (!decision.answer || decision.answer.trim().length < 8) return {
		pass: false,
		reason: "Empty or too-short answer"
	};
	if (decision.confidence < .55) return {
		pass: false,
		reason: `Confidence ${decision.confidence.toFixed(2)} below threshold`
	};
	if (/sandbox|calculat|compound|\d+\s*%/.test(request) && !tools.some((t) => t.name === "sandbox" && t.ok)) {
		if (/\b\d+\b/.test(decision.answer) && decision.confidence >= .8) return {
			pass: true,
			reason: "Numeric answer with high confidence"
		};
	}
	return {
		pass: true,
		reason: "Answer present and confidence above threshold"
	};
}
function seedMemory() {
	return [{
		id: "proc-sandbox",
		kind: "procedural",
		title: "Sandbox policy",
		body: "Only sandbox, retrieve, memory, orbita_status. No shell. Destroy worker after result.",
		createdAt: Date.now() - 864e5
	}, {
		id: "proc-escalate",
		kind: "procedural",
		title: "Escalation rules",
		body: "Escalate when confidence < 0.55, governed research, or verification fails.",
		createdAt: Date.now() - 864e5
	}];
}
function getSystemStatusHandler() {
	const stats = corpusStats();
	return {
		ai: aiAvailable(),
		student: "grok-4.5 · worker",
		teacher: "grok-4.5 · supervisor",
		retrieval: `${stats.documents} docs · ${stats.tokens} tokens · BM25+rerank`,
		sandbox: "policy engine · isolated python",
		orbita: "SHA-256 freeze · independent eval",
		desktop: "XFCE · noVNC · Tailscale-only"
	};
}
async function executeRun(data) {
	const started = Date.now();
	const steps = [];
	const toolTrace = [];
	const memory = seedMemory();
	let desk = data.desktop ?? initialDesktop();
	const id = crypto.randomUUID();
	const t0 = Date.now();
	const retrieved = retrieve(data.request, 5);
	steps.push(step("retrieve", "Language tower", `Top ${retrieved.length} passages after BM25 + rerank`, {
		latencyMs: Date.now() - t0,
		data: {
			ids: retrieved.map((d) => d.id),
			titles: retrieved.map((d) => d.title)
		}
	}));
	if (!aiAvailable()) {
		if (data.mode === "governed") return localGoverned({
			id,
			started,
			request: data.request,
			mode: data.mode,
			retrieved,
			steps,
			toolTrace,
			memory,
			desk
		});
		return offlineRun({
			id,
			started,
			request: data.request,
			mode: data.mode,
			retrieved,
			steps,
			toolTrace,
			memory,
			reason: "Local worker · language tower + sandbox",
			desk
		});
	}
	if (data.mode === "governed") return runGoverned({
		id,
		started,
		request: data.request,
		mode: data.mode,
		retrieved,
		steps,
		toolTrace,
		memory,
		desk
	});
	steps.push(step("route", "Model router", "Student first · teacher on fail / low confidence", { data: { choice: "student" } }));
	const historyMsgs = data.history.map((h) => ({
		role: h.role,
		content: h.content
	}));
	const baseMsgs = [
		{
			role: "system",
			content: STUDENT_SYS
		},
		...historyMsgs,
		{
			role: "user",
			content: `Request:\n${data.request}\n\nRetrieved context:\n${docsBlock(retrieved)}`
		}
	];
	let apiCalls = 0;
	let raw = await studentChat(baseMsgs);
	apiCalls += 1;
	if (!raw.ok) return offlineRun({
		id,
		started,
		request: data.request,
		mode: data.mode,
		retrieved,
		steps,
		toolTrace,
		memory,
		reason: "Retrieval + sandbox worker · generative model skipped",
		desk
	});
	let decision = parseDecision(raw.text);
	if (!decision) decision = {
		thought: "Could not parse structured output",
		confidence: .2,
		action: "escalate",
		answer: raw.text.slice(0, 1200)
	};
	steps.push(step("reason", "Student reason", decision.thought || "Structured action", {
		model: "student",
		data: {
			action: decision.action,
			confidence: decision.confidence
		}
	}));
	let rounds = 0;
	while (decision.action === "tool" && decision.tool && rounds < 2 && apiCalls < 3) {
		const tTool = Date.now();
		const executed = await executeTool(decision.tool, memory, desk);
		desk = executed.desk;
		const result = executed.result;
		toolTrace.push(result);
		if (decision.tool.name === "memory_write") memory.push({
			id: `work-${memory.length}`,
			kind: "working",
			title: decision.tool.arguments.title ?? "note",
			body: decision.tool.arguments.body ?? "",
			createdAt: Date.now()
		});
		steps.push(step("tool", `Sandbox / tool · ${decision.tool.name}`, result.output.slice(0, 280), {
			latencyMs: Date.now() - tTool,
			data: {
				ok: result.ok,
				name: result.name
			}
		}));
		raw = await studentChat([
			...baseMsgs,
			{
				role: "assistant",
				content: JSON.stringify(decision)
			},
			{
				role: "user",
				content: `Tool ${result.name} ${result.ok ? "ok" : "failed"}:\n${result.output}\nContinue. JSON only.`
			}
		]);
		apiCalls += 1;
		if (!raw.ok) break;
		decision = parseDecision(raw.text) ?? {
			thought: "parse fail after tool",
			confidence: .25,
			action: "escalate"
		};
		rounds += 1;
		steps.push(step("reason", "Student continue", decision.thought || decision.action, {
			model: "student",
			data: {
				action: decision.action,
				confidence: decision.confidence
			}
		}));
	}
	if (decision.action !== "tool" && (!decision.answer || decision.answer.trim().length < 8)) {
		const lastOk = [...toolTrace].reverse().find((t) => t.ok);
		if (lastOk) decision = {
			...decision,
			action: "answer",
			answer: lastOk.output,
			confidence: Math.max(decision.confidence, .7)
		};
	}
	const verdict = verify(data.request, decision, toolTrace);
	steps.push(step("verify", "Verifier", verdict.reason, { data: {
		pass: verdict.pass,
		confidence: decision.confidence
	} }));
	if ((decision.action === "escalate" || !verdict.pass || decision.confidence < .55) && apiCalls < 3) {
		steps.push(step("escalate", "Escalate to teacher", "Student failed verification or requested supervision", { model: "teacher" }));
		const tTeach = await teacherChat([{
			role: "system",
			content: TEACHER_SYS
		}, {
			role: "user",
			content: `Original request:\n${data.request}\n\nRetrieved:\n${docsBlock(retrieved)}\n\nStudent attempt:\n${JSON.stringify(decision)}\n\nTool trace:\n${toolTrace.map((t) => t.name + ": " + t.output).join("\n")}\n\nVerifier: ${verdict.reason}\nProduce the corrected final answer as JSON with action=answer.`
		}]);
		apiCalls += 1;
		if (!tTeach.ok) return offlineRun({
			id,
			started,
			request: data.request,
			mode: data.mode,
			retrieved,
			steps,
			toolTrace,
			memory,
			reason: "Teacher skipped · answering from tower and sandbox",
			desk
		});
		const teacherDec = parseDecision(tTeach.text);
		const answer = teacherDec?.answer || tTeach.text;
		const training = {
			id: `tr-${id.slice(0, 8)}`,
			prompt: data.request,
			studentAttempt: decision.answer || decision.thought || JSON.stringify(decision),
			teacherAnswer: answer,
			verification: "fail",
			createdAt: Date.now()
		};
		steps.push(step("answer", "Teacher answer", "Supervised completion", { model: "teacher" }));
		return {
			id,
			createdAt: started,
			request: data.request,
			mode: data.mode,
			status: "ok",
			escalated: true,
			modelPath: "student→teacher",
			answer,
			citations: teacherDec?.citations ?? retrieved.map((d) => d.id).slice(0, 3),
			confidence: teacherDec?.confidence ?? .8,
			steps,
			retrieved,
			toolTrace,
			training,
			desktop: desk,
			tokensHint: `${apiCalls} model calls`,
			totalMs: Date.now() - started
		};
	}
	steps.push(step("answer", "Student answer", "Passed verification", { model: "student" }));
	return {
		id,
		createdAt: started,
		request: data.request,
		mode: data.mode,
		status: "ok",
		escalated: false,
		modelPath: "student",
		answer: decision.answer || "No answer.",
		citations: decision.citations ?? retrieved.map((d) => d.id).slice(0, 3),
		confidence: decision.confidence,
		steps,
		retrieved,
		toolTrace,
		desktop: desk,
		tokensHint: `${apiCalls} model calls`,
		totalMs: Date.now() - started
	};
}
async function runGoverned(opts) {
	const { id, started, request, retrieved, steps, toolTrace, memory } = opts;
	let desk = opts.desk;
	steps.push(step("route", "Model router", "Governed path · teacher proposes a frozen plan", { data: { choice: "teacher" } }));
	steps.push(step("orbita", "Orbita case", "Opened governed case from request + tower context"));
	const planRes = await teacherChat([{
		role: "system",
		content: TEACHER_SYS
	}, {
		role: "user",
		content: `Create a governed experiment/analysis plan for:\n${request}\n\nCase context:\n${docsBlock(retrieved)}\n\nJSON with thought, plan (full text), answer (brief summary of what will be tested), confidence, citations.`
	}], {
		maxTokens: 900,
		json: true
	});
	if (!planRes.ok) return localGoverned({
		id,
		started,
		request,
		mode: opts.mode,
		retrieved,
		steps,
		toolTrace,
		memory,
		desk
	});
	const planned = parseDecision(planRes.text);
	const planText = extractField(planRes.text, "plan") || planned?.answer || planRes.text;
	let record = compilePlan(request, planText);
	steps.push(step("orbita", "Compile + freeze", `SHA-256 ${record.planHash.slice(0, 16)}…`, { data: {
		planHash: record.planHash,
		caseId: record.caseId
	} }));
	record = approvePlan(record);
	steps.push(step("orbita", "Approve plan", "Approval boundary crossed · plan is now immutable"));
	if (/sandbox|python|compute|calculate|FV|precision/i.test(planText)) {
		const executed = await executeTool({
			name: "sandbox",
			arguments: { code: extractPython(planText) ?? "print(round(10000 * (1.07 ** 12), 2))" }
		}, memory, desk);
		desk = executed.desk;
		const result = executed.result;
		toolTrace.push(result);
		steps.push(step("tool", "Sandbox execution", result.output.slice(0, 280), { data: { ok: result.ok } }));
	}
	const evalRes = await teacherChat([{
		role: "system",
		content: TEACHER_SYS
	}, {
		role: "user",
		content: `Evaluate this FROZEN plan. You may not change the plan.
PLAN HASH: ${record.planHash}
PLAN:\n${record.plan}
TOOL TRACE:\n${toolTrace.map((t) => t.output).join("\n") || "(none)"}
ORIGINAL QUESTION:\n${request}
JSON with thought, answer (the governed result), evaluation_pass (boolean), evaluation_notes, confidence, citations.`
	}], {
		maxTokens: 700,
		json: true
	});
	if (!evalRes.ok) return localGoverned({
		id,
		started,
		request,
		mode: opts.mode,
		retrieved,
		steps,
		toolTrace,
		memory,
		existingPlan: record.plan,
		desk
	});
	const evaluated = parseDecision(evalRes.text);
	const evalPass = extractBool(evalRes.text, "evaluation_pass") ?? true;
	const evalNotes = extractField(evalRes.text, "evaluation_notes") || evaluated?.thought || "Independent evaluation recorded.";
	record = attachDiscovery(record, evaluated?.answer || evalRes.text.slice(0, 1500));
	record = evaluateRecord(record, {
		pass: evalPass,
		notes: evalNotes
	});
	steps.push(step("verify", "Independent evaluation", evalNotes.slice(0, 220), { data: {
		pass: evalPass,
		planHash: record.planHash
	} }));
	steps.push(step("answer", "Governed result", "Frozen plan + evaluation recorded", { model: "teacher" }));
	const answer = evaluated?.answer || `Governed result for ${record.caseId}. Plan hash ${record.planHash.slice(0, 12)}. ${evalNotes}`;
	return {
		id,
		createdAt: started,
		request,
		mode: opts.mode,
		status: "ok",
		escalated: true,
		modelPath: "teacher",
		answer,
		citations: evaluated?.citations ?? retrieved.map((d) => d.id).slice(0, 3),
		confidence: evaluated?.confidence ?? .82,
		steps,
		retrieved,
		toolTrace,
		orbita: record,
		desktop: desk,
		tokensHint: "2 teacher calls",
		totalMs: Date.now() - started
	};
}
function inferPython(request) {
	const money = request.match(/\$\s*([\d,]+)/);
	const rate = request.match(/(\d+(?:\.\d+)?)\s*%/);
	const years = request.match(/(\d+)\s*years?/);
	if (money && rate && years) return `print(round(${money[1].replace(/,/g, "")} * (1 + ${Number(rate[1]) / 100}) ** ${years[1]}, 2))`;
	return null;
}
function answerFromTower(request, docs, tools) {
	const deskOut = tools.find((t) => t.name === "desktop");
	if (deskOut) {
		const cite = docs[0] ? `\n\n${docs[0].title} — ${docs[0].text.slice(0, 280)}` : "";
		return `${deskOut.output}${cite}`.trim();
	}
	const calc = tools.find((t) => t.name === "sandbox" && t.ok);
	if (calc) return `Sandbox result: ${calc.output}\n\n${docs[0] ? docs[0].title + " — " + docs[0].text.slice(0, 360) : ""}`.trim();
	if (!docs.length) return `No passages matched “${request.slice(0, 80)}”, and the generative worker is offline.`;
	return docs.slice(0, 3).map((d, i) => `${i + 1}. ${d.title}\n${d.text.split(/(?<=\.)\s+/).slice(0, 2).join(" ")}`).join("\n\n");
}
async function maybeLocalTools(request, memory, desk) {
	const tools = [];
	const code = inferPython(request);
	if (code) {
		const executed = await executeTool({
			name: "sandbox",
			arguments: { code }
		}, memory, desk);
		desk = executed.desk;
		tools.push(executed.result);
	}
	if (/pocketdesktop|screenshot|launch chromium|desktop status|novnc|xfce/i.test(request)) {
		if (desk.status !== "running") {
			const booted = await executeTool({
				name: "desktop",
				arguments: { action: "start" }
			}, memory, desk);
			desk = booted.desk;
			tools.push(booted.result);
		}
		const executed = await executeTool({
			name: "desktop",
			arguments: {
				action: /screenshot/i.test(request) ? "screenshot" : /launch/i.test(request) ? "launch" : "status",
				app: "chromium"
			}
		}, memory, desk);
		desk = executed.desk;
		tools.push(executed.result);
	}
	return {
		tools,
		desk
	};
}
async function offlineRun(opts) {
	const { id, started, request, retrieved, steps, toolTrace, memory, reason } = opts;
	let desk = opts.desk;
	if (!steps.some((s) => s.kind === "route")) steps.push(step("route", "Model router", reason, { data: { choice: "student" } }));
	const extra = await maybeLocalTools(request, memory, desk);
	desk = extra.desk;
	for (const t of extra.tools) {
		toolTrace.push(t);
		steps.push(step("tool", `Sandbox / tool · ${t.name}`, t.output.slice(0, 280), { data: {
			ok: t.ok,
			name: t.name
		} }));
	}
	const answer = answerFromTower(request, retrieved, toolTrace);
	steps.push(step("verify", "Verifier", "Tower passages present; generative worker skipped"));
	steps.push(step("answer", "Tower answer", reason, { model: "student" }));
	return {
		id,
		createdAt: started,
		request,
		mode: opts.mode,
		status: "ok",
		escalated: false,
		modelPath: "student",
		answer,
		citations: retrieved.map((d) => d.id).slice(0, 4),
		confidence: retrieved.length ? .62 : .3,
		steps,
		retrieved,
		toolTrace,
		desktop: desk,
		tokensHint: "0 model calls",
		totalMs: Date.now() - started
	};
}
async function localGoverned(opts) {
	const { id, started, request, retrieved, steps, toolTrace, memory } = opts;
	let desk = opts.desk;
	if (!steps.some((s) => s.kind === "route")) {
		steps.push(step("route", "Model router", "Governed path · local freeze (teacher offline)", { data: { choice: "teacher" } }));
		steps.push(step("orbita", "Orbita case", "Opened governed case from request + tower context"));
	}
	let record = compilePlan(request, opts.existingPlan ?? `Hypothesis: ${request}
Method: Retrieve from the language tower, freeze this plan, run numeric checks in the sandbox if present, and score the answer against retrieved ids ${retrieved.map((d) => d.id).join(", ") || "(none)"}.
Success: A concrete cited answer, or a numeric result that matches the sandbox.
Falsification: Empty answer, denied tool, or no supporting passage.
Sandbox: numeric evaluation only when the question contains a calculation.`);
	steps.push(step("orbita", "Compile + freeze", `SHA-256 ${record.planHash.slice(0, 16)}…`, { data: {
		planHash: record.planHash,
		caseId: record.caseId
	} }));
	record = approvePlan(record);
	steps.push(step("orbita", "Approve plan", "Approval boundary crossed · plan is now immutable"));
	const extra = await maybeLocalTools(request, memory, desk);
	desk = extra.desk;
	for (const t of extra.tools) {
		toolTrace.push(t);
		steps.push(step("tool", "Sandbox execution", t.output.slice(0, 280), { data: { ok: t.ok } }));
	}
	const discovery = answerFromTower(request, retrieved, toolTrace);
	const pass = discovery.length > 40 && (toolTrace.length === 0 || toolTrace.some((t) => t.ok));
	record = attachDiscovery(record, discovery);
	record = evaluateRecord(record, {
		pass,
		notes: pass ? "Independent eval against frozen plan: supporting passages (and sandbox, if used) match success criteria." : "Independent eval: insufficient evidence. Record kept as a negative governed result."
	});
	steps.push(step("verify", "Independent evaluation", record.evaluation?.notes ?? "", { data: {
		pass,
		planHash: record.planHash
	} }));
	steps.push(step("answer", "Governed result", "Frozen plan + evaluation recorded", { model: "teacher" }));
	return {
		id,
		createdAt: started,
		request,
		mode: opts.mode,
		status: "ok",
		escalated: true,
		modelPath: "teacher",
		answer: `${discovery}\n\nCase ${record.caseId}. Plan hash ${record.planHash.slice(0, 16)}. ${record.evaluation?.notes}`,
		citations: retrieved.map((d) => d.id).slice(0, 4),
		confidence: .7,
		steps,
		retrieved,
		toolTrace,
		orbita: record,
		desktop: desk,
		tokensHint: "0 model calls",
		totalMs: Date.now() - started
	};
}
function extractField(raw, key) {
	try {
		const start = raw.indexOf("{");
		const end = raw.lastIndexOf("}");
		if (start < 0 || end <= start) return void 0;
		const v = JSON.parse(raw.slice(start, end + 1))[key];
		return typeof v === "string" ? v : void 0;
	} catch {
		return;
	}
}
function extractBool(raw, key) {
	try {
		const start = raw.indexOf("{");
		const end = raw.lastIndexOf("}");
		if (start < 0 || end <= start) return void 0;
		const v = JSON.parse(raw.slice(start, end + 1))[key];
		if (typeof v === "boolean") return v;
		return;
	} catch {
		return;
	}
}
function extractPython(plan) {
	const m = plan.match(/```(?:python)?\n([\s\S]*?)```/);
	if (m?.[1]) return m[1].trim();
	return null;
}
function listCorpusHandler() {
	return CORPUS.map((d) => ({
		id: d.id,
		title: d.title,
		tags: d.tags,
		excerpt: d.text.slice(0, 180)
	}));
}
//#endregion
export { executeRun, getSystemStatusHandler, listCorpusHandler };
