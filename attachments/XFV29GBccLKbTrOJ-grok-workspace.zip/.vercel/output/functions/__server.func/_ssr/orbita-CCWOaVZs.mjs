import { i as __toESM } from "../_runtime.mjs";
import { B as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as hashPreview } from "./router-CaGnAOj7.mjs";
import { t as Badge } from "./badge-w3Tfyg13.mjs";
import { t as Button } from "./button-C-DP-0vH.mjs";
import { t as useLab } from "./store-DNIW78pj.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/orbita-CCWOaVZs.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function OrbitaView() {
	const experiments = useLab((s) => s.experiments);
	const [openId, setOpenId] = (0, import_react.useState)(experiments[0]?.caseId ?? null);
	const open = experiments.find((e) => e.caseId === openId) ?? experiments[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid min-h-[calc(100dvh-3.5rem)] md:min-h-dvh md:grid-cols-[minmax(0,0.9fr)_minmax(0,1.1fr)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "border-b border-border px-4 py-6 md:border-b-0 md:border-r md:px-6 md:py-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-[10px] uppercase tracking-[0.18em] text-subtle",
					children: "HodgeForm"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 font-display text-3xl tracking-tight",
					children: "Frozen before tested."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 max-w-md text-sm leading-relaxed text-muted",
					children: "Ordinary thoughts skip this path. Research, model improvement, and claims you care about become a case: compile, hash, approve, discover, evaluate."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-8 space-y-3 font-mono text-xs text-muted",
					children: [
						"orbita_case_context",
						"orbita_compile_plan",
						"orbita_submit_plan",
						"SHA-256 freeze",
						"orbita_approve_plan",
						"orbita_run_discovery",
						"independent evaluation"
					].map((row, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-subtle",
							children: ["0", i + 1]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-fg",
							children: row
						})]
					}, row))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-8 text-sm text-muted",
					children: "Open Console, switch to Governed, and ask for an experiment. The teacher writes the plan; Orbita freezes it before anyone runs it."
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "px-4 py-6 md:px-6 md:py-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-baseline justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm text-fg",
						children: "Cases"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "font-mono text-[10px] text-subtle",
						children: [experiments.length, " records"]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-4 space-y-2",
					children: experiments.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setOpenId(e.caseId),
						className: "w-full rounded-[var(--radius-md)] border border-border bg-bg-elevated px-4 py-3 text-left hover:border-border-strong",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-[10px] text-subtle",
								children: e.caseId
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, {
								status: e.status,
								pass: e.evaluation?.pass
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-1 text-sm text-fg",
							children: e.question
						})]
					}) }, e.caseId))
				}),
				open && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "mt-6 rounded-[var(--radius-xl)] border border-border bg-bg-elevated p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-[11px] text-muted",
								children: open.caseId
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-mono text-[11px] text-subtle",
								children: ["sha256 ", hashPreview(open.planHash)]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-3 text-lg text-fg",
							children: open.question
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
							className: "mt-4 overflow-x-auto whitespace-pre-wrap font-mono text-xs leading-relaxed text-muted",
							children: open.plan
						}),
						open.discovery && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-mono text-[10px] uppercase tracking-[0.14em] text-subtle",
								children: "Discovery"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-fg",
								children: open.discovery
							})]
						}),
						open.evaluation && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 flex items-start justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted",
								children: open.evaluation.notes
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, {
								status: "evaluated",
								pass: open.evaluation.pass
							})]
						}),
						open.status === "frozen" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "mt-4",
							size: "sm",
							onClick: () => useLab.getState().approveExperiment(open.caseId),
							children: "Approve plan"
						})
					]
				})
			]
		})]
	});
}
function StatusBadge({ status, pass }) {
	if (status === "evaluated") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
		tone: pass ? "ok" : "fail",
		children: pass ? "pass" : "fail"
	});
	if (status === "frozen") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
		tone: "warn",
		children: "frozen"
	});
	if (status === "approved") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
		tone: "live",
		children: "approved"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: status });
}
function OrbitaPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrbitaView, {});
}
//#endregion
export { OrbitaPage as component };
