import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/api-DhikR1Sd.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var getSystemStatus_createServerFn_handler = createServerRpc({
	id: "2af88fd0e65b35b615d69e45cc893025902a17f41b2501e583baf1f8b098c0be",
	name: "getSystemStatus",
	filename: "src/lib/agent/api.ts"
}, (opts) => getSystemStatus.__executeServer(opts));
var getSystemStatus = createServerFn({ method: "GET" }).handler(getSystemStatus_createServerFn_handler, async () => {
	const { getSystemStatusHandler } = await import("./orchestrator.server-BoLwwIc4.mjs");
	return getSystemStatusHandler();
});
var listCorpus_createServerFn_handler = createServerRpc({
	id: "aa9316d55bfd4fd389945356d6ec15f6fd7b416e2ac9017a19f0b016fa64923a",
	name: "listCorpus",
	filename: "src/lib/agent/api.ts"
}, (opts) => listCorpus.__executeServer(opts));
var listCorpus = createServerFn({ method: "GET" }).handler(listCorpus_createServerFn_handler, async () => {
	const { listCorpusHandler } = await import("./orchestrator.server-BoLwwIc4.mjs");
	return listCorpusHandler();
});
var runAgent_createServerFn_handler = createServerRpc({
	id: "5a883aeda48a7c277fc8d161d1c2939700d59765653c6b0c344daba878a2fb56",
	name: "runAgent",
	filename: "src/lib/agent/api.ts"
}, (opts) => runAgent.__executeServer(opts));
var runAgent = createServerFn({ method: "POST" }).validator((input) => {
	const request = (input?.request ?? "").trim().slice(0, 4e3);
	if (!request) throw new Error("Request required");
	return {
		request,
		mode: input.mode === "governed" ? "governed" : "fast",
		history: (input.history ?? []).slice(-6).map((h) => ({
			role: h.role === "assistant" ? "assistant" : "user",
			content: String(h.content).slice(0, 2e3)
		})),
		desktop: input.desktop
	};
}).handler(runAgent_createServerFn_handler, async ({ data }) => {
	const { executeRun } = await import("./orchestrator.server-BoLwwIc4.mjs");
	return executeRun(data);
});
//#endregion
export { getSystemStatus_createServerFn_handler, listCorpus_createServerFn_handler, runAgent_createServerFn_handler };
