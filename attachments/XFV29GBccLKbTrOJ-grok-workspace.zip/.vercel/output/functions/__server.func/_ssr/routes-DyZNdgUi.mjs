import { i as __toESM } from "../_runtime.mjs";
import { B as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { c as LoaderCircle, h as ArrowUp } from "../_libs/lucide-react.mjs";
import { n as cn } from "./router-CaGnAOj7.mjs";
import { t as ArchitectureMap } from "./architecture-map-CmiWTv95.mjs";
import { t as Badge } from "./badge-w3Tfyg13.mjs";
import { t as useDesktop } from "./desktop-store-DSEsB1fI.mjs";
import { t as Button } from "./button-C-DP-0vH.mjs";
import { t as useLab } from "./store-DNIW78pj.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DyZNdgUi.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
createServerFn({ method: "GET" }).handler(createSsrRpc("2af88fd0e65b35b615d69e45cc893025902a17f41b2501e583baf1f8b098c0be"));
createServerFn({ method: "GET" }).handler(createSsrRpc("aa9316d55bfd4fd389945356d6ec15f6fd7b416e2ac9017a19f0b016fa64923a"));
var runAgent = createServerFn({ method: "POST" }).validator((input) => {
	const request = (input?.request ?? "").trim().slice(0, 4e3);
	if (!request) throw new Error("Request required");
	return {
		request,
		mode: input.mode === "governed" ? "governed" : "fast",
		history: (input.history ?? []).slice(-6).map((h) => ({
			role: h.role === "assistant" ? "assistant" : "user",
			content: String(h.content).slice(0, 2e3)
		})),
		desktop: input.desktop
	};
}).handler(createSsrRpc("5a883aeda48a7c277fc8d161d1c2939700d59765653c6b0c344daba878a2fb56"));
function PipelineStrip({ steps, visible, running }) {
	const shown = steps.slice(0, Math.max(visible, 0));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
		className: "flex flex-col gap-2",
		children: [shown.map((s, i) => {
			const last = i === shown.length - 1 && running && visible < steps.length;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "rise-in flex gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col items-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("mt-1 size-2 rounded-full", last ? "bg-accent pipeline-live" : "bg-fg/70") }), i < shown.length - 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mt-1 w-px flex-1 bg-border" })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 pb-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-baseline gap-x-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-[10px] uppercase tracking-[0.14em] text-subtle",
								children: s.kind
							}), s.model && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: cn("font-mono text-[10px] uppercase tracking-[0.12em]", s.model === "teacher" ? "text-teacher" : "text-student"),
								children: s.model
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-sm text-fg",
							children: s.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-0.5 text-xs leading-relaxed text-muted",
							children: s.detail
						})
					]
				})]
			}, s.id);
		}), running && shown.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
			className: "font-mono text-xs text-muted",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "shimmer-text",
				children: "Retrieving context…"
			})
		})]
	});
}
function RunMeta({ run }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-wrap gap-x-4 gap-y-1 font-mono text-[11px] text-muted",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [run.totalMs, " ms"] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: run.tokensHint }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: run.escalated ? "text-teacher" : "text-student",
				children: run.modelPath
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [Math.round(run.confidence * 100), "% conf"] })
		]
	});
}
var Textarea = import_react.forwardRef(({ className, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		ref,
		className: cn("min-h-[44px] w-full resize-none rounded-[var(--radius-md)] border border-border bg-bg-elevated px-3 py-2.5 text-sm text-fg placeholder:text-subtle outline-none transition-colors duration-150 focus:border-border-strong focus:ring-2 focus:ring-accent/30", className),
		...props
	});
});
Textarea.displayName = "Textarea";
var SAMPLES = [
	{
		label: "Architecture",
		text: "Why shouldn't the agent live inside vLLM, and when does the student escalate to the teacher?"
	},
	{
		label: "Sandbox",
		text: "Use the sandbox to compute the future value of $10,000 compounded at 7% annually for 12 years."
	},
	{
		label: "Memory",
		text: "What are the six memory kinds Orbita keeps outside the prompt window?"
	},
	{
		label: "Desktop",
		text: "Take a PocketDesktop screenshot and say which apps are allow-listed. Do not use sudo."
	},
	{
		label: "Governed",
		text: "Propose a governed experiment: does requiring JSON schema on the worker reduce tool parse failures?"
	}
];
function ConsoleView() {
	const mode = useLab((s) => s.mode);
	const setMode = useLab((s) => s.setMode);
	const turns = useLab((s) => s.turns);
	const runs = useLab((s) => s.runs);
	const activeRunId = useLab((s) => s.activeRunId);
	const replayIndex = useLab((s) => s.replayIndex);
	const setReplayIndex = useLab((s) => s.setReplayIndex);
	const addUserTurn = useLab((s) => s.addUserTurn);
	const completeRun = useLab((s) => s.completeRun);
	const failUserTurn = useLab((s) => s.failUserTurn);
	const clearSession = useLab((s) => s.clearSession);
	const [draft, setDraft] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const scroller = (0, import_react.useRef)(null);
	const active = runs.find((r) => r.id === activeRunId) ?? runs[0];
	const visibleSteps = active ? replayIndex : 0;
	(0, import_react.useEffect)(() => {
		scroller.current?.scrollTo({
			top: scroller.current.scrollHeight,
			behavior: "smooth"
		});
	}, [turns.length, busy]);
	(0, import_react.useEffect)(() => {
		if (!active || busy) return;
		setReplayIndex(1);
		if (active.steps.length <= 1) return;
		let i = 1;
		const id = window.setInterval(() => {
			i += 1;
			setReplayIndex(i);
			if (i >= active.steps.length) window.clearInterval(id);
		}, 260);
		return () => window.clearInterval(id);
	}, [
		active?.id,
		busy,
		setReplayIndex
	]);
	const liveKind = (0, import_react.useMemo)(() => {
		if (!active) return void 0;
		const idx = Math.max(0, Math.min(visibleSteps, active.steps.length) - 1);
		return active.steps[idx]?.kind;
	}, [active, visibleSteps]);
	const liveModel = (0, import_react.useMemo)(() => {
		if (!active) return void 0;
		const idx = Math.max(0, Math.min(visibleSteps, active.steps.length) - 1);
		return active.steps[idx]?.model;
	}, [active, visibleSteps]);
	const liveTool = (0, import_react.useMemo)(() => {
		if (!active) return void 0;
		const idx = Math.max(0, Math.min(visibleSteps, active.steps.length) - 1);
		return active.steps[idx]?.data?.name;
	}, [active, visibleSteps]);
	async function submit(text, nextMode = mode) {
		const request = text.trim();
		if (!request || busy) return;
		setDraft("");
		setBusy(true);
		const history = useLab.getState().turns.slice(-6).map((t) => ({
			role: t.role,
			content: t.content
		}));
		const turnId = addUserTurn(request);
		try {
			const run = await runAgent({ data: {
				request,
				mode: nextMode,
				history,
				desktop: useDesktop.getState().snap
			} });
			completeRun(turnId, run);
		} catch (e) {
			failUserTurn(turnId, e instanceof Error ? e.message : "Agent failed");
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid md:min-h-dvh md:grid-cols-[minmax(0,1.15fr)_minmax(280px,0.85fr)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "flex h-[calc(100dvh-7.25rem)] min-h-0 flex-col border-b border-border md:h-dvh md:border-b-0 md:border-r",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-3 border-b border-border px-4 py-3 md:px-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-xl tracking-tight md:text-2xl",
						children: "Console"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted",
						children: "Retrieve · route · act · verify"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModeSwitch, {
							mode,
							onChange: setMode,
							disabled: busy
						}), turns.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "sm",
							onClick: clearSession,
							children: "Clear"
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					ref: scroller,
					className: "flex-1 space-y-5 overflow-y-auto px-4 py-5 md:px-6",
					children: [
						turns.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, { onPick: (s) => {
							if (s.label === "Governed") setMode("governed");
							submit(s.text, s.label === "Governed" ? "governed" : mode);
						} }),
						turns.map((t) => {
							const run = t.runId ? runs.find((r) => r.id === t.runId) : void 0;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("article", {
								className: "rise-in",
								children: t.role === "user" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "ml-auto max-w-[46rem] rounded-[var(--radius-lg)] bg-bg-subtle px-4 py-3 text-sm leading-relaxed",
									children: t.content
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "max-w-[46rem] rounded-[var(--radius-lg)] border border-border bg-bg-elevated px-4 py-3",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "mb-2 flex flex-wrap items-center gap-2",
											children: run && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
													tone: run.escalated ? "teacher" : "student",
													children: run.modelPath
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
													tone: run.status === "ok" ? "ok" : "fail",
													children: run.status
												}),
												run.orbita && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
													tone: "live",
													children: "governed"
												})
											] })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "whitespace-pre-wrap text-sm leading-relaxed text-fg",
											children: t.content
										}),
										run && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-3 space-y-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RunMeta, { run }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
												className: "md:hidden",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("summary", {
													className: "cursor-pointer font-mono text-[10px] uppercase tracking-[0.14em] text-subtle",
													children: [
														"Pipeline · ",
														run.steps.length,
														" steps"
													]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "mt-2",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PipelineStrip, {
														steps: run.steps,
														visible: run.steps.length
													})
												})]
											})]
										})
									]
								})
							}, t.id);
						}),
						busy && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 text-sm text-muted",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "shimmer-text",
								children: mode === "governed" ? "Freezing a plan…" : "Worker is running…"
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "border-t border-border p-3 md:p-4",
					onSubmit: (e) => {
						e.preventDefault();
						submit(draft);
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-end gap-2 rounded-[var(--radius-lg)] border border-border bg-bg-elevated p-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							value: draft,
							onChange: (e) => setDraft(e.target.value),
							onKeyDown: (e) => {
								if (e.key === "Enter" && !e.shiftKey) {
									e.preventDefault();
									submit(draft);
								}
							},
							placeholder: mode === "governed" ? "Ask for a claim you actually want tested…" : "Ask the worker. Escalate only if it must.",
							rows: 2,
							className: "border-0 bg-transparent focus:ring-0",
							disabled: busy
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							size: "icon",
							disabled: busy || !draft.trim(),
							"aria-label": "Send",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUp, {})
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 px-1 font-mono text-[10px] uppercase tracking-[0.14em] text-subtle",
						children: mode === "governed" ? "Governed · teacher plan · SHA-256 freeze · independent eval" : "Fast loop · student first · teacher on fail"
					})]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "hidden min-h-0 flex-col bg-bg md:flex",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "border-b border-border px-4 py-3 md:px-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "font-mono text-[10px] uppercase tracking-[0.16em] text-subtle",
					children: "Live layers"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-1 text-sm text-fg",
					children: "Architecture while it thinks"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-5 overflow-y-auto px-4 py-4 md:px-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArchitectureMap, {
						compact: true,
						activeKind: liveKind,
						activeModel: liveModel,
						activeTool: liveTool
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mb-2 font-mono text-[10px] uppercase tracking-[0.16em] text-subtle",
						children: "Pipeline"
					}), active ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PipelineStrip, {
						steps: active.steps,
						visible: Math.max(visibleSteps, busy ? 2 : 0),
						running: busy
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Send a request to watch retrieve, route, tools, and verify light up."
					})] }),
					active && active.retrieved.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mb-2 font-mono text-[10px] uppercase tracking-[0.16em] text-subtle",
						children: "Tower hits"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "space-y-2",
						children: active.retrieved.slice(0, 4).map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "rounded-[var(--radius-sm)] border border-border px-3 py-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-baseline justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm text-fg",
									children: d.title
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono text-[10px] text-subtle",
									children: d.score.toFixed(2)
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-mono text-[10px] text-muted",
								children: d.id
							})]
						}, d.id))
					})] })
				]
			})]
		})]
	});
}
function ModeSwitch({ mode, onChange, disabled }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex rounded-[var(--radius-sm)] border border-border p-0.5",
		children: ["fast", "governed"].map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			disabled,
			onClick: () => onChange(m),
			className: cn("h-8 rounded-[6px] px-3 font-mono text-[10px] uppercase tracking-[0.12em]", mode === m ? "bg-bg-subtle text-fg" : "text-muted"),
			children: m
		}, m))
	});
}
function EmptyState({ onPick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-lg py-6 md:py-16",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-3xl tracking-tight text-fg md:text-4xl",
				children: "Cheap worker. Strong teacher. Frozen evaluation."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 max-w-md text-sm leading-relaxed text-muted",
				children: "The student handles ordinary work through the language tower and a locked sandbox. Hard claims go to the teacher, then Orbita hashes the plan before anything is treated as a result."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 grid gap-2",
				children: SAMPLES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => onPick(s),
					className: "rounded-[var(--radius-md)] border border-border bg-bg-elevated px-4 py-3 text-left transition-colors duration-150 hover:border-border-strong",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "font-mono text-[10px] uppercase tracking-[0.14em] text-subtle",
						children: s.label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-1 text-sm text-fg",
						children: s.text
					})]
				}, s.label))
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConsoleView, {});
}
//#endregion
export { Home as component };
