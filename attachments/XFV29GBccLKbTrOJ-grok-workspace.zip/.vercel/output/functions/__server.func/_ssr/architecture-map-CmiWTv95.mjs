import { b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as cn } from "./router-CaGnAOj7.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/architecture-map-CmiWTv95.js
var import_jsx_runtime = require_jsx_runtime();
var NODES = [
	{
		id: "api",
		label: "Agent API",
		sub: "FastAPI surface",
		kinds: ["answer"]
	},
	{
		id: "orchestrator",
		label: "Orchestrator",
		sub: "router · state · policy",
		kinds: ["route", "verify"]
	},
	{
		id: "student",
		label: "Student / vLLM",
		sub: "worker SLM",
		kinds: ["reason"]
	},
	{
		id: "tower",
		label: "Language tower",
		sub: "embed · retrieve · rerank",
		kinds: ["retrieve"]
	},
	{
		id: "orbita",
		label: "Orbita / HodgeForm",
		sub: "frozen plans",
		kinds: ["orbita"]
	},
	{
		id: "vector",
		label: "Vector memory",
		sub: "pgvector / Qdrant",
		kinds: ["retrieve"]
	},
	{
		id: "sandbox",
		label: "Sandbox workers",
		sub: "isolated tools",
		kinds: ["tool"]
	},
	{
		id: "desktop",
		label: "PocketDesktop",
		sub: "XFCE · noVNC · Tailscale",
		kinds: ["tool"]
	},
	{
		id: "teacher",
		label: "Teacher LLM",
		sub: "supervise · evaluate",
		kinds: ["escalate"]
	}
];
function activeFor(kind, node, model, tool) {
	if (!kind) return false;
	if (node.id === "student" && kind === "reason" && model === "teacher") return false;
	if (node.id === "teacher" && kind === "reason" && model === "teacher") return true;
	if (node.id === "teacher" && kind === "answer" && model === "teacher") return true;
	if (node.id === "desktop") return kind === "tool" && tool === "desktop";
	if (node.id === "sandbox") return kind === "tool" && tool !== "desktop";
	return node.kinds.includes(kind);
}
function ArchitectureMap({ activeKind, activeModel, activeTool, compact = false, onSelect, selected }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("grid gap-2", compact ? "grid-cols-2" : "grid-cols-2 md:grid-cols-4"),
		children: NODES.map((node) => {
			const on = activeFor(activeKind, node, activeModel, activeTool);
			const isSel = selected === node.id;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => onSelect?.(node.id),
				className: cn("rounded-[var(--radius-md)] border px-3 py-3 text-left transition-[border-color,background-color] duration-200", compact ? "py-2" : "py-3", on ? "pipeline-live border-accent/60 bg-accent/10" : "border-border bg-bg-elevated hover:border-border-strong", isSel && "border-fg/40"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "font-mono text-[10px] uppercase tracking-[0.16em] text-subtle",
						children: node.id
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: cn("mt-1 text-sm text-fg", compact && "text-[13px]"),
						children: node.label
					}),
					!compact && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-0.5 text-xs text-muted",
						children: node.sub
					})
				]
			}, node.id);
		})
	});
}
var NODE_COPY = {
	api: "Entry surface. The user never talks to a model directly — every request hits the orchestrator through this API.",
	orchestrator: "Router, working state, tool policy, and verifier. Chooses student vs teacher, executes structured actions, and records traces.",
	student: "Small worker model served as if it were vLLM: OpenAI-compatible completions, JSON schema, ordinary tool calls.",
	tower: "Semantic understanding outside the generator. BM25 retrieval over the corpus, then a title/tag rerank before the prompt is built.",
	orbita: "Scientific governor. Plans are compiled, SHA-256 frozen, approved, then discovered and evaluated independently of the proposer.",
	vector: "Semantic memory for documents, successful traces, and long-lived knowledge. Not the conversation window.",
	sandbox: "Isolated execution. The model emits a schema-checked action; a worker runs it; the container is conceptually destroyed.",
	desktop: "PocketDesktop is a private XFCE target, not a root shell. Narrow API: screenshot, click, type, launch allow-listed apps (chromium, files, terminal, calculator). Tailscale-only exposure, 20-minute idle halt. Start/stop is an operator action; sudo is denied.",
	teacher: "Strong supervisor. Called on low confidence, verification failure, or governed research. Successful corrections become training records."
};
//#endregion
export { NODE_COPY as n, ArchitectureMap as t };
