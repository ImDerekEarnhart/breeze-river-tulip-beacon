//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BFzmI6xf.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/architecture",
			"/desktop",
			"/memory",
			"/orbita",
			"/traces"
		],
		preloads: ["/assets/index-D0rjTUrJ.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-D0rjTUrJ.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-DAcfbxM1.js",
			"/assets/architecture-map-Bu7exRiM.js",
			"/assets/badge-BxkyjcCY.js",
			"/assets/desktop-store-Da_L06S0.js",
			"/assets/button-BhQhhsPh.js",
			"/assets/store-E-pvHxO8.js"
		]
	},
	"/architecture": {
		filePath: "/workspace/src/routes/architecture.tsx",
		children: void 0,
		preloads: [
			"/assets/architecture-CU2i-VcI.js",
			"/assets/architecture-map-Bu7exRiM.js",
			"/assets/badge-BxkyjcCY.js"
		]
	},
	"/desktop": {
		filePath: "/workspace/src/routes/desktop.tsx",
		children: void 0,
		preloads: [
			"/assets/desktop-C0OiQ_EN.js",
			"/assets/badge-BxkyjcCY.js",
			"/assets/desktop-store-Da_L06S0.js",
			"/assets/button-BhQhhsPh.js"
		]
	},
	"/memory": {
		filePath: "/workspace/src/routes/memory.tsx",
		children: void 0,
		preloads: [
			"/assets/memory-CHAI6oNC.js",
			"/assets/badge-BxkyjcCY.js",
			"/assets/store-E-pvHxO8.js"
		]
	},
	"/orbita": {
		filePath: "/workspace/src/routes/orbita.tsx",
		children: void 0,
		preloads: [
			"/assets/orbita-BleVoWbO.js",
			"/assets/badge-BxkyjcCY.js",
			"/assets/button-BhQhhsPh.js",
			"/assets/store-E-pvHxO8.js"
		]
	},
	"/traces": {
		filePath: "/workspace/src/routes/traces.tsx",
		children: void 0,
		preloads: [
			"/assets/traces-CNZX3Qwz.js",
			"/assets/badge-BxkyjcCY.js",
			"/assets/store-E-pvHxO8.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
