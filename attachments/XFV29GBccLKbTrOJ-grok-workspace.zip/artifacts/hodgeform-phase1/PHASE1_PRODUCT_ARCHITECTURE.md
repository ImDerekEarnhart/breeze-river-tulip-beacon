# Hodgeform Phase 1 — Product & Architecture

**Status:** Phase 1 alignment deliverable  
**Authority:** *Hodgeform Product Blueprint* (authoritative product direction)  
**Scope:** parity matrix, canonical object model, Guided card set, MCP tool list, capability registry contract  
**Non-goals:** PocketDesktop, student/teacher routing as architecture, LoRA, GPU VM student host, frontend-only discovery logic

---

## 1. Product identity (Phase 1)

Hodgeform is a **model-agnostic governed discovery system**. It turns an uncertain question into an inspectable evidence process:

```text
question
  → evidence intake
  → explicit candidate or plan
  → pre-execution freeze
  → bounded execution
  → falsification and independent verification
  → scope-limited claim
  → durable provenance and follow-up questions
```

**One governed core. Two channels.**

| Channel | Audience | Surface |
|---|---|---|
| **Hodgeform Guided** | Humans | Conversational web app with progressive governance disclosure |
| **Hodgeform MCP** | External AI hosts (ChatGPT, Claude, Gemini, Codex, …) | Typed tools over the same tenant-scoped services |

Neither channel is a separate scientific engine. Both must produce the same object types, hashes, state transitions, and receipts.

**Standing authority rule:**

```text
proposal ≠ evidence ≠ admission ≠ authorization ≠ activation
```

**Naming (customer-facing):**

- **Hodgeform** — product and platform  
- **Hodgeform Guided** — human conversational product  
- **Hodgeform MCP** — AI-agent integration  
- **Hodgeform Core** — governed services and evidence model  
- **Hodgeform Verify** — independent verification workflows (Lean and others, as available)  
- **Hodgeform Tower** — representation adequacy / retrieval (narrow introduction only)  

“Orbita” / “OrbitaLab” may remain as legacy internal package or API aliases only. They are not a second platform.

---

## 2. Phase 1 delivery target and gate

### Deliver

1. Hodgeform naming and shared product vocabulary  
2. One **capability registry** consumed by Guided and MCP  
3. One **case / evidence / claim lifecycle** across both surfaces  
4. Chat-first Guided workflow with **typed governance cards**  
5. Visible **parity matrix** (this document §3)  
6. Production build identity present in capabilities and receipts  
7. Append-only verification attempts with monotonic canonical acceptance  
8. End-to-end documentation based on real deployed behavior (this doc + registry)

### Gate

A fresh user can complete **one case through Guided** and **one through MCP** and retrieve **equivalent** hashes, statuses, claims, questions, and receipts for the same logical work.

### Explicit Phase 1 non-goals

- GPU VM / local student model as product identity  
- Autonomous LoRA from unreviewed failures  
- General-purpose or root-capable desktop agent  
- Separate memory databases outside shared evidence objects  
- Frontend-only discovery logic  
- Automatic code/architecture promotion  
- ASI branding  
- Claiming full Guided/MCP parity before the parity acceptance suite passes  

PocketDesktop is **out of Phase 1**. If ever introduced, it is a Phase 5 governed action adapter only.

---

## 3. Parity matrix (Guided ↔ MCP)

**Invariant:** No scientific behavior may exist only in frontend JavaScript. No MCP tool may bypass the core because an advanced model called it.

| Capability | Guided | MCP | Shared invariant |
|---|---|---|---|
| Create case | Chat / “New case” | `hf_case_create` | Same tenant + `case_id` |
| Inspect case | Case summary card + expand | `hf_case_get` | Same case payload + status |
| List cases | Sidebar / history | `hf_case_list` | Same filters and ordering contract |
| Add evidence (text) | Paste / upload text | `hf_artifact_add` | Same content hash + provenance |
| Add evidence (file) | Upload workflow | `hf_artifact_add` (bytes or URI policy) | Same media type + hash |
| Profile evidence | Analyze mode card | `hf_evidence_profile` | Same profile object |
| Propose candidate | Model-assisted draft in chat | `hf_candidate_propose` | Candidate is draft until admitted |
| Submit / compile plan | Freeze review UI | `hf_plan_submit` | Same immutable plan payload |
| Get plan | Expand plan card | `hf_plan_get` | Same plan hash |
| Approve transition | Explicit confirmation UI | `hf_approve` (exact hash + phrase) | Same approval receipt |
| Execute plan | Progress card | `hf_execute` | Same dispatcher + executor contract |
| Get execution receipt | Expand result | `hf_execution_get` | Same receipt hash |
| Request verification | Verify action | `hf_verify` | Same verifier identity + scope |
| Get verification receipt | Receipt card | `hf_verification_get` | Append-only attempts; monotonic accept |
| Record / read claim | Claim boundary card | `hf_claim_get` / `hf_claim_list` | Same claim scope guards |
| Record counterexample | Refutation card | `hf_counterexample_add` | Durable; does not erase prior accept |
| Next questions | Question cards | `hf_question_list` / `hf_question_propose` | Same admissibility state |
| List capabilities | Settings / about | `hf_capabilities` | Same registry version + build id |
| Health / build identity | About strip | `hf_health` | Same `build_id`, `core_version` |

### Mode mapping (Guided UX → core)

| Guided mode | Allowed without freeze | Requires Govern path |
|---|---|---|
| **Ask** | Explanation, retrieval, summarization, uncertainty | No governed execution, no claim of research run |
| **Analyze** | Profile, candidate relationships, bounded analysis | Execution of consequential claims still needs Govern |
| **Govern** | Full lifecycle | Freeze → Approve → Execute → Evaluate → Verify/Reject |

MCP does not have “modes” as UI; tools carry explicit `intent` or the case’s `mode` field. Tools that would perform governed transitions fail closed without freeze + approval when policy requires them.

---

## 4. Canonical object model

Objects are **append-only or versioned**. Failed validation creates **attempt receipts**; it does not overwrite a prior accepted verification or erase its canonical receipt.

Every durable object includes at minimum:

| Field | Meaning |
|---|---|
| `id` | Stable identifier |
| `tenant_id` | Tenant isolation key |
| `created_at` | ISO-8601 UTC |
| `content_hash` | Immutable hash of canonical payload (SHA-256, hex) |
| `status` | Lifecycle status for that object type |
| `provenance` | Source, actor, parent links |

### 4.1 Object catalog

| Object | Purpose | Minimum binding |
|---|---|---|
| **Case** | Unit of user intent and evidence | tenant, question, scope, artifact set, mode |
| **Artifact** | Immutable supplied or produced material | bytes/content hash, media type, source |
| **EvidenceReceipt** | Normalized evidence without rewriting source | source hash, scope, independence, eligibility |
| **Candidate** | Testable relationship, operator, prediction, or repair | kind, inputs, outcome, assumptions, falsifier |
| **Plan** | Exact proposed method | candidates, coverage, executor contracts, hashes |
| **Approval** | Human authority for one exact transition | object hash, confirmation, identity, timestamp |
| **ExecutionReceipt** | What actually ran | plan hash, executor hash, inputs, outputs, errors |
| **VerificationReceipt** | Separate verification outcome | artifact/plan hash, verifier identity, scope, result |
| **Claim** | Bounded interpretation | evidence status, scope, support/refutation links |
| **Counterexample** | Durable challenge to a candidate or claim | witness, affected object, verification state |
| **QuestionRecord** | Proposed next question | admissibility, required data, test, stopping rule |
| **LanguageSnapshot** | Frozen finite expressive surface *(Phase 3 primary)* | primitives, observables, semantics, provenance |
| **LanguageLimitCertificate** | Bounded proof of a representational hole *(Phase 3)* | snapshot, gap, verifier receipt |
| **RepairCandidate** | Inactive proposed primitive or policy repair | parent, prediction contract, risk/cost |
| **ImprovementCandidate** | Inactive system change | exact patch/config, evaluation contract |

Phase 1 **must implement** solidly: Case, Artifact, EvidenceReceipt, Candidate, Plan, Approval, ExecutionReceipt, VerificationReceipt, Claim, Counterexample, QuestionRecord.

Phase 1 **may stub** LanguageSnapshot / certificates / improvement objects as registry entries with `status: not_available` rather than inventing behavior.

### 4.2 Case lifecycle (shared)

```text
open
  → evidence_attached
  → candidates_drafted
  → plan_submitted
  → plan_frozen
  → approved
  → running
  → executed
  → evaluated
  → verified | rejected | inconclusive
  → follow_up
  → closed
```

Not every case walks every step. **Ask** cases may stop at evidence + answer without freeze. **Govern** cases that claim a consequential result without freeze/approval **fail closed**.

### 4.3 Plan freeze contract

A frozen plan is immutable. Canonical payload includes:

- `case_id`
- ordered candidate list (each with kind, inputs, falsifier)
- executor contract identities
- coverage / untested regions statement
- `plan_hash = SHA-256(canonical_json)`

After freeze, only **approval**, **execution against the frozen hash**, **verification**, and **claim recording** may proceed. Rewriting the plan creates a **new** plan object; it does not mutate the frozen one.

### 4.4 Claim scope guards

A claim must declare:

- `support_status`: supported | refuted | inconclusive | not_tested  
- `scope`: what population / condition / time / method the claim applies to  
- links to evidence receipts and (if any) counterexamples  

Hodgeform **blocks** unsupported escalations (e.g., association → causality, finite test → universal proof) rather than silently translating the question.

---

## 5. Guided card set

Guided is **chat-first**. The user sees one conversation with progressive disclosure. Typed cards are the default surface; advanced users expand to exact JSON, hashes, and receipts.

### 5.1 Required cards (Phase 1)

| Card id | When shown | Primary fields (user-visible) | Expand reveals |
|---|---|---|---|
| `evidence_received` | After artifact intake | name, media type, size, source | content_hash, provenance |
| `archive_profile` | Analyze mode after profile | schema summary, row/cols, missingness, warnings | full profile JSON |
| `candidate_relationship` | Draft candidate proposed | kind, inputs → outcome, assumptions | falsifier, candidate_hash |
| `artifact_warning` | Leakage / integrity risk | warning type, severity, affected fields | detection receipt |
| `research_question` | Question framed or refined | question text, mode | admissibility, stopping rule |
| `method_falsifier` | Plan drafting | method summary, what would disprove | full candidate set |
| `freeze_review` | Before approve | plan summary, hash prefix, executor list | full plan JSON + plan_hash |
| `approval_request` | Govern transition | what is frozen, why approval, claim scope risk | exact object_hash, policy id |
| `execution_progress` | While running | stage, executor, elapsed | live receipt id |
| `survivor_refutation` | After evaluation | survived / refuted / inconclusive | links to receipts |
| `verification_receipt` | After verify | verifier, result, scope | attempt history (append-only) |
| `claim_boundary` | After claim recorded | plain-English boundary of what was established | claim object + scope guards |
| `next_question` | Follow-up | question, required data, test | QuestionRecord full |
| `stopping_boundary` | Honest stop | why work stopped without rescue | policy + missing requirements |

### 5.2 Card rendering rules

1. Default view is plain English + one primary action.  
2. Hashes shown abbreviated (e.g. first 12 hex chars) with copy-full.  
3. Expand always available when an object id exists.  
4. Cards are **views** over core objects—not a second source of truth.  
5. Model prose in the chat stream may summarize cards but must not replace them for governed transitions.

### 5.3 Mode chrome

- **Ask** — minimal cards; no freeze/approve chrome unless user escalates mode.  
- **Analyze** — profile + candidate + warning cards common.  
- **Govern** — freeze → approval → execution → verification → claim cards required in order for consequential claims.

---

## 6. MCP tool list (Phase 1)

All tools are tenant-scoped. Authentication and tenant binding are gateway concerns (OAuth / API key → tenant_id). Tools return structured objects + `content_hash` fields; they do not return free-form “trust me” conclusions as scientific fact.

### 6.1 Tool inventory

| Tool | Role | Governed? |
|---|---|---|
| `hf_health` | Build identity and liveness | No |
| `hf_capabilities` | Capability registry snapshot | No |
| `hf_case_create` | Open a case | No (creates shell) |
| `hf_case_get` | Read case | No |
| `hf_case_list` | List cases | No |
| `hf_artifact_add` | Attach immutable artifact | No (intake) |
| `hf_evidence_profile` | Profile attached evidence | No / Analyze |
| `hf_candidate_propose` | Draft candidate (not admitted) | No |
| `hf_plan_submit` | Compile + freeze plan | Freeze boundary |
| `hf_plan_get` | Read plan by id/hash | No |
| `hf_approve` | Human-equivalent exact approval | Authorization |
| `hf_execute` | Dispatch frozen plan | Execution |
| `hf_execution_get` | Read execution receipt | No |
| `hf_verify` | Request independent verification | Verification |
| `hf_verification_get` | Read verification attempts/receipts | No |
| `hf_claim_record` | Record scope-limited claim | Claim boundary |
| `hf_claim_get` / `hf_claim_list` | Read claims | No |
| `hf_counterexample_add` | Attach durable counterexample | No (append) |
| `hf_question_propose` | Propose next admissible question | No |
| `hf_question_list` | List questions for case | No |

### 6.2 Approval tool discipline

`hf_approve` requires:

- `object_type` + `object_id`  
- `object_hash` exactly matching the frozen object  
- `confirmation_phrase` exact match to server-issued challenge (or configured policy phrase)  
- caller identity bound by gateway  

Mismatch → fail closed; emit attempt receipt; do not approve.

### 6.3 Execute tool discipline

`hf_execute` requires:

- `plan_id` + `plan_hash` match frozen plan  
- prior approval receipt when policy says so  
- registered executor for each candidate kind  

Unknown candidate kind → fail closed (no silent rewrite to an easier executor).

---

## 7. Capability registry (contract)

The registry is the **single source of truth** for what Guided and MCP may offer. Both surfaces load the same versioned document (see `capability_registry.json`).

### 7.1 Registry fields

| Field | Meaning |
|---|---|
| `registry_version` | Semver of registry schema |
| `core_version` | Hodgeform Core software version |
| `build_id` | Production build identity |
| `generated_at` | UTC timestamp |
| `capabilities[]` | List of capability records |

### 7.2 Capability record

| Field | Meaning |
|---|---|
| `id` | Stable capability id (e.g. `case.create`) |
| `title` | Human label |
| `description` | One-line purpose |
| `mcp_tools` | MCP tool names implementing it |
| `guided` | `available` \| `partial` \| `unavailable` |
| `mcp` | `available` \| `partial` \| `unavailable` |
| `requires_approval` | boolean |
| `requires_freeze` | boolean |
| `phase` | Minimum product phase (1–5) |
| `status` | `active` \| `stub` \| `deferred` |

### 7.3 Parity rule

If `guided` and `mcp` both claim `available` for a capability, the acceptance suite must prove equivalent durable objects and hashes. If only one channel is available, the registry must say so—**no silent partial implementation marketed as parity**.

---

## 8. Execution architecture (Phase 1 subset)

```text
candidate kind
  → registered executor identity
  → capability + schema validation
  → frozen input + policy hashes
  → approval (if required)
  → execution in bounded environment
  → raw output + ExecutionReceipt
  → separate verification (when requested / required)
```

**Phase 1 executor families (minimum viable):**

1. **Passthrough / deterministic echo** — plumbing tests only; not for product claims  
2. **Statistical table analysis** — association / group difference on attached tables  
3. **Bounded external experiment** — pinned code/data, no network, resource limits *(if worker present; else mark deferred in registry)*  

Lean finite verification and blind calibration may appear as `stub` / `deferred` until workers exist. Availability of an executor does **not** make its result true: execution integrity, empirical support, and formal proof are different statuses.

---

## 9. Models and routing (Phase 1 stance)

Models are **replaceable adapters**. They may:

- translate language into candidate plans  
- summarize exact retrieved evidence  
- propose hypotheses, falsifiers, follow-up questions  
- interpret bounded results  

They may **not**:

- silently approve  
- alter frozen artifacts  
- broaden claim scope  
- promote improvements  
- deploy changes  

Student/teacher routing is **not** Phase 1 architecture. A deployment may use one model or several; any routing policy must be versioned and measured later (Phase 4).

---

## 10. Memory stance (Phase 1)

Memory is **one case-centered evidence graph** with logical views—not six product databases:

- working state  
- semantic evidence  
- episodic traces  
- procedural contracts  
- experimental records  
- training candidates *(later consumer of accepted pairs)*  

Model conversation text is not automatically trusted memory.

---

## 11. Success checks for Phase 1 acceptance

| Check | Pass criterion |
|---|---|
| Identity | Product presents as Hodgeform; Orbita only as legacy alias if needed |
| Dual channel | Same case completable via Guided and MCP |
| Hash parity | plan_hash, artifact hashes, claim ids match across channels for same work |
| Freeze immutability | Mutating frozen plan rejected; new plan is new object |
| Approval exactness | Wrong hash or phrase fails; attempt logged |
| Verification append-only | Failed verify does not erase prior accepted receipt |
| Claim guards | Unsupported scope escalation blocked with explicit reason |
| Registry truth | `hf_capabilities` matches actual tool availability |
| No desktop dependency | Product functions without PocketDesktop |

---

## 12. Related artifacts

| File | Purpose |
|---|---|
| `capability_registry.json` | Machine-readable registry (Guided + MCP) |
| `mcp_tools.schema.json` | JSON Schema for MCP tool input/output contracts |
| `PHASE1_PRODUCT_ARCHITECTURE.md` | This document |

---

## 13. Release narrative (Phase 1)

> Hodgeform is the governed evidence layer for AI-assisted discovery. Your preferred AI can propose hypotheses and interpret results, while Hodgeform freezes the method, runs bounded checks, preserves counterexamples, verifies what it can, and prevents the final claim from outrunning the evidence. Use it conversationally through Hodgeform Guided or connect an AI directly through Hodgeform MCP.

Until Phase 1 gate conditions hold, new models, desktops, and training loops increase surface area more than product strength.
