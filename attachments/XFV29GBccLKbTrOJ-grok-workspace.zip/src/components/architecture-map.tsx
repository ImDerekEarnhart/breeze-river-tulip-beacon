import { cn } from "@/lib/utils";
import type { StepKind } from "@/lib/agent/types";

export type NodeId =
  | "api"
  | "orchestrator"
  | "student"
  | "tower"
  | "orbita"
  | "vector"
  | "sandbox"
  | "teacher"
  | "desktop";

const NODES: {
  id: NodeId;
  label: string;
  sub: string;
  kinds: StepKind[];
}[] = [
  { id: "api", label: "Agent API", sub: "FastAPI surface", kinds: ["answer"] },
  {
    id: "orchestrator",
    label: "Orchestrator",
    sub: "router · state · policy",
    kinds: ["route", "verify"],
  },
  { id: "student", label: "Student / vLLM", sub: "worker SLM", kinds: ["reason"] },
  {
    id: "tower",
    label: "Language tower",
    sub: "embed · retrieve · rerank",
    kinds: ["retrieve"],
  },
  { id: "orbita", label: "Orbita / HodgeForm", sub: "frozen plans", kinds: ["orbita"] },
  { id: "vector", label: "Vector memory", sub: "pgvector / Qdrant", kinds: ["retrieve"] },
  { id: "sandbox", label: "Sandbox workers", sub: "isolated tools", kinds: ["tool"] },
  { id: "desktop", label: "PocketDesktop", sub: "XFCE · noVNC · Tailscale", kinds: ["tool"] },
  { id: "teacher", label: "Teacher LLM", sub: "supervise · evaluate", kinds: ["escalate"] },
];

function activeFor(
  kind: StepKind | undefined,
  node: (typeof NODES)[number],
  model?: string,
  tool?: string,
) {
  if (!kind) return false;
  if (node.id === "student" && kind === "reason" && model === "teacher") return false;
  if (node.id === "teacher" && kind === "reason" && model === "teacher") return true;
  if (node.id === "teacher" && kind === "answer" && model === "teacher") return true;
  if (node.id === "desktop") return kind === "tool" && tool === "desktop";
  if (node.id === "sandbox") return kind === "tool" && tool !== "desktop";
  return node.kinds.includes(kind);
}

export function ArchitectureMap({
  activeKind,
  activeModel,
  activeTool,
  compact = false,
  onSelect,
  selected,
}: {
  activeKind?: StepKind;
  activeModel?: string;
  activeTool?: string;
  compact?: boolean;
  selected?: NodeId | null;
  onSelect?: (id: NodeId) => void;
}) {
  return (
    <div className={cn("grid gap-2", compact ? "grid-cols-2" : "grid-cols-2 md:grid-cols-4")}>
      {NODES.map((node) => {
        const on = activeFor(activeKind, node, activeModel, activeTool);
        const isSel = selected === node.id;
        return (
          <button
            key={node.id}
            type="button"
            onClick={() => onSelect?.(node.id)}
            className={cn(
              "rounded-[var(--radius-md)] border px-3 py-3 text-left transition-[border-color,background-color] duration-200",
              compact ? "py-2" : "py-3",
              on
                ? "pipeline-live border-accent/60 bg-accent/10"
                : "border-border bg-bg-elevated hover:border-border-strong",
              isSel && "border-fg/40",
            )}
          >
            <div className="font-mono text-[10px] uppercase tracking-[0.16em] text-subtle">
              {node.id}
            </div>
            <div className={cn("mt-1 text-sm text-fg", compact && "text-[13px]")}>{node.label}</div>
            {!compact && <div className="mt-0.5 text-xs text-muted">{node.sub}</div>}
          </button>
        );
      })}
    </div>
  );
}

export const NODE_COPY: Record<NodeId, string> = {
  api: "Entry surface. The user never talks to a model directly — every request hits the orchestrator through this API.",
  orchestrator:
    "Router, working state, tool policy, and verifier. Chooses student vs teacher, executes structured actions, and records traces.",
  student:
    "Small worker model served as if it were vLLM: OpenAI-compatible completions, JSON schema, ordinary tool calls.",
  tower:
    "Semantic understanding outside the generator. BM25 retrieval over the corpus, then a title/tag rerank before the prompt is built.",
  orbita:
    "Scientific governor. Plans are compiled, SHA-256 frozen, approved, then discovered and evaluated independently of the proposer.",
  vector:
    "Semantic memory for documents, successful traces, and long-lived knowledge. Not the conversation window.",
  sandbox:
    "Isolated execution. The model emits a schema-checked action; a worker runs it; the container is conceptually destroyed.",
  desktop:
    "PocketDesktop is a private XFCE target, not a root shell. Narrow API: screenshot, click, type, launch allow-listed apps (chromium, files, terminal, calculator). Tailscale-only exposure, 20-minute idle halt. Start/stop is an operator action; sudo is denied.",
  teacher:
    "Strong supervisor. Called on low confidence, verification failure, or governed research. Successful corrections become training records.",
};
