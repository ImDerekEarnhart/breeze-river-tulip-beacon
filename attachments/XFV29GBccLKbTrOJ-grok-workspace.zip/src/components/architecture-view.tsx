import { useState } from "react";
import { ArchitectureMap, NODE_COPY, type NodeId } from "@/components/architecture-map";
import { Badge } from "@/components/ui/badge";

const PHASES = [
  {
    n: "01",
    title: "Worker loop",
    body: "GPU VM, vLLM student, orchestrator, a handful of tools. One agent that can finish a structured task.",
  },
  {
    n: "02",
    title: "Language tower",
    body: "Embedding, vector search, rerank. Stop spending generator tokens on memory.",
  },
  {
    n: "03",
    title: "Teacher routing",
    body: "Student first. Escalate on low confidence or failed verify. Collect traces.",
  },
  {
    n: "04",
    title: "Orbita",
    body: "Teacher proposes. Plan is hashed. Approval boundary. Discovery. Independent evaluation.",
  },
  {
    n: "05",
    title: "Improve the worker",
    body: "Failures → teacher → falsification → training set → LoRA. The worker never rewrites itself.",
  },
  {
    n: "06",
    title: "PocketDesktop",
    body: "A private XFCE target with a narrow API. Screenshots, pointer, keys, allow-listed apps. Never sudo.",
  },
];
export function ArchitectureView() {
  const [selected, setSelected] = useState<NodeId | null>("orchestrator");

  return (
    <div className="px-4 py-6 md:px-8 md:py-8">
      <div className="max-w-3xl">
        <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-subtle">
          System
        </p>
        <h1 className="mt-2 font-display text-3xl tracking-tight md:text-4xl">
          Not a model with a shell attached.
        </h1>
        <p className="mt-3 max-w-2xl text-sm leading-relaxed text-muted md:text-base">
          Inference, retrieval, governance, and execution are separate. The agent is
          the loop that binds them. Click a layer.
        </p>
      </div>

      <div className="mt-8">
        <ArchitectureMap selected={selected} onSelect={setSelected} />
      </div>

      {selected && (
        <div className="mt-5 max-w-2xl rounded-[var(--radius-lg)] border border-border bg-bg-elevated px-5 py-4">
          <div className="font-mono text-[10px] uppercase tracking-[0.16em] text-subtle">
            {selected}
          </div>
          <p className="mt-2 text-sm leading-relaxed text-fg">{NODE_COPY[selected]}</p>
        </div>
      )}

      <section className="mt-12">
        <h2 className="font-display text-2xl tracking-tight">Two loops</h2>
        <div className="mt-4 grid gap-4 md:grid-cols-2">
          <article className="rounded-[var(--radius-xl)] border border-border bg-bg-elevated p-5">
            <Badge tone="student">Fast</Badge>
            <h3 className="mt-3 text-lg text-fg">Milliseconds to seconds</h3>
            <p className="mt-2 text-sm leading-relaxed text-muted">
              User → retrieve → student → tool → verify → answer. The worker stays
              cheap. Tools never share a process with the model.
            </p>
          </article>
          <article className="rounded-[var(--radius-xl)] border border-border bg-bg-elevated p-5">
            <Badge tone="teacher">Governed</Badge>
            <h3 className="mt-3 text-lg text-fg">When the claim matters</h3>
            <p className="mt-2 text-sm leading-relaxed text-muted">
              Case → teacher plan → SHA-256 freeze → approval → discovery → sandbox
              → independent evaluation. A proposal is not a result.
            </p>
          </article>
        </div>
      </section>

      <section className="mt-12 pb-8">
        <h2 className="font-display text-2xl tracking-tight">Build order</h2>
        <ol className="mt-4 grid gap-3">
          {PHASES.map((p) => (
            <li
              key={p.n}
              className="grid grid-cols-[auto_1fr] gap-4 rounded-[var(--radius-md)] border border-border px-4 py-3"
            >
              <span className="font-mono text-xs text-subtle">{p.n}</span>
              <div>
                <div className="text-sm text-fg">{p.title}</div>
                <p className="mt-1 text-sm text-muted">{p.body}</p>
              </div>
            </li>
          ))}
        </ol>
      </section>
    </div>
  );
}
