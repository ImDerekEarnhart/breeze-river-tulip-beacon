const STUDENT_MODEL = "grok-4.5";
const TEACHER_MODEL = "grok-4.5";
const FALLBACK_MODELS = ["grok-4.5", "grok-4.6", "grok-4"];

export function aiAvailable() {
  return Boolean(process.env.XAI_API_KEY);
}

type ChatMessage = {
  role: "system" | "user" | "assistant";
  content: string;
};

type ChatResult =
  | { ok: true; text: string; model: string }
  | { ok: false; error: string };

async function postChat(
  model: string,
  messages: ChatMessage[],
  opts: { maxTokens: number; temperature: number; json?: boolean },
): Promise<ChatResult> {
  const apiKey = process.env.XAI_API_KEY;
  if (!apiKey) return { ok: false, error: "AI is not available in this environment" };

  const body: Record<string, unknown> = {
    model,
    messages,
    max_tokens: opts.maxTokens,
    temperature: opts.temperature,
  };
  if (opts.json) {
    body.response_format = { type: "json_object" };
  }

  const res = await fetch("https://api.x.ai/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify(body),
  });

  if (!res.ok) {
    const errText = await res.text().catch(() => "");
    return { ok: false, error: `xAI API error ${res.status}${errText ? `: ${errText.slice(0, 180)}` : ""}` };
  }

  const data = (await res.json()) as {
    choices?: { message?: { content?: string } }[];
    model?: string;
  };
  const text = data.choices?.[0]?.message?.content ?? "";
  return { ok: true, text, model: data.model ?? model };
}

async function chatWithFallback(
  preferred: string,
  messages: ChatMessage[],
  opts: { maxTokens: number; temperature: number; json?: boolean },
): Promise<ChatResult> {
  const models = [preferred, ...FALLBACK_MODELS.filter((m) => m !== preferred)];
  let last: ChatResult = { ok: false, error: "No model attempted" };
  for (const model of models) {
    last = await postChat(model, messages, opts);
    if (last.ok) return last;
    if (!/404|400|model/.test(last.error)) return last;
  }
  return last;
}

export function studentChat(
  messages: ChatMessage[],
  opts?: { maxTokens?: number },
) {
  return chatWithFallback(STUDENT_MODEL, messages, {
    maxTokens: opts?.maxTokens ?? 500,
    temperature: 0.2,
    json: true,
  });
}

export function teacherChat(
  messages: ChatMessage[],
  opts?: { maxTokens?: number; json?: boolean },
) {
  return chatWithFallback(TEACHER_MODEL, messages, {
    maxTokens: opts?.maxTokens ?? 900,
    temperature: 0.3,
    json: opts?.json ?? true,
  });
}
