import { retrieve, corpusStats } from "./language-tower";
import { executeTool, TOOL_SCHEMAS } from "./tools";
import { aiAvailable, studentChat, teacherChat } from "./xai.server";
import {
  approvePlan,
  attachDiscovery,
  compilePlan,
  evaluateRecord,
} from "./orbita";
import { CORPUS } from "./corpus";
import { initialDesktop, type DeskSnapshot } from "../desktop";
import type {
  AgentDecision,
  AgentMode,
  MemoryItem,
  RetrievedDoc,
  RunStep,
  RunTrace,
  ToolCall,
  ToolName,
  ToolResult,
  TrainingRecord,
} from "./types";

function step(
  kind: RunStep["kind"],
  title: string,
  detail: string,
  extra?: Partial<RunStep>,
): RunStep {
  return {
    id: crypto.randomUUID().slice(0, 8),
    kind,
    title,
    detail,
    latencyMs: extra?.latencyMs ?? 0,
    model: extra?.model,
    data: extra?.data,
  };
}



function parseDecision(raw: string): AgentDecision | null {
  const trimmed = raw.trim();
  const start = trimmed.indexOf("{");
  const end = trimmed.lastIndexOf("}");
  if (start < 0 || end <= start) return null;
  try {
    const obj = JSON.parse(trimmed.slice(start, end + 1)) as Record<string, unknown>;
    const action =
      obj.action === "tool" || obj.action === "escalate" || obj.action === "answer"
        ? obj.action
        : "answer";
    const toolRaw = obj.tool as { name?: string; arguments?: Record<string, unknown> } | undefined;
    let tool: ToolCall | undefined;
    if (toolRaw?.name) {
      const args: Record<string, string> = {};
      if (toolRaw.arguments && typeof toolRaw.arguments === "object") {
        for (const [k, v] of Object.entries(toolRaw.arguments)) {
          args[k] = typeof v === "string" ? v : JSON.stringify(v);
        }
      }
      tool = { name: toolRaw.name as ToolName, arguments: args };
    }
    return {
      thought: String(obj.thought ?? ""),
      confidence: Math.max(0, Math.min(1, Number(obj.confidence ?? 0.5))),
      action,
      tool,
      answer: obj.answer ? String(obj.answer) : undefined,
      citations: Array.isArray(obj.citations)
        ? obj.citations.map((c) => String(c))
        : undefined,
    };
  } catch {
    return null;
  }
}

const STUDENT_SYS = `You are Orbita's worker SLM. Handle ordinary tasks: classify, retrieve, extract, tool use, simple coding, short answers.
Respond ONLY as JSON:
{
  "thought": "short",
  "confidence": 0.0-1.0,
  "action": "answer" | "tool" | "escalate",
  "tool": { "name": "sandbox"|"retrieve"|"memory_read"|"memory_write"|"orbita_status"|"desktop", "arguments": { } },
  "answer": "final answer if action=answer",
  "citations": ["doc-id"]
}
Tools: ${TOOL_SCHEMAS.map((t) => `${t.name}: ${t.description}`).join(" | ")}
Rules:
- Use sandbox for numeric work. Python only, no files/network.
- PocketDesktop is screenshot/click/type/launch only. Never sudo or ssh.
- Cite retrieved doc ids when you used them.
- Escalate if confidence < 0.55, the task is experimental design, or you cannot verify.
- Keep answers tight and specific. No markdown tables.`;

const TEACHER_SYS = `You are Orbita's teacher LLM. You handle difficult reasoning, supervision, verification, and governed experiment plans.
Respond ONLY as JSON with keys thought, confidence, action, answer, citations, and optionally plan, discovery, evaluation_pass, evaluation_notes.
If asked to propose a governed plan, put the full frozen-ready plan in "plan" with Hypothesis, Method, Success, Falsification, Sandbox steps.
If asked to evaluate, set evaluation_pass boolean and evaluation_notes.
Be precise. Prefer falsifiable statements.`;

function docsBlock(docs: RetrievedDoc[]) {
  if (!docs.length) return "No retrieved passages.";
  return docs
    .map(
      (d) =>
        `[${d.id}] ${d.title} (score ${d.score.toFixed(2)})\n${d.text.slice(0, 700)}`,
    )
    .join("\n\n");
}

function verify(request: string, decision: AgentDecision, tools: ToolResult[]) {
  if (!decision.answer || decision.answer.trim().length < 8) {
    return { pass: false, reason: "Empty or too-short answer" };
  }
  if (decision.confidence < 0.55) {
    return { pass: false, reason: `Confidence ${decision.confidence.toFixed(2)} below threshold` };
  }
  if (/sandbox|calculat|compound|\d+\s*%/.test(request) && !tools.some((t) => t.name === "sandbox" && t.ok)) {
    if (/\b\d+\b/.test(decision.answer) && decision.confidence >= 0.8) {
      return { pass: true, reason: "Numeric answer with high confidence" };
    }
  }
  return { pass: true, reason: "Answer present and confidence above threshold" };
}

function seedMemory(): MemoryItem[] {
  return [
    {
      id: "proc-sandbox",
      kind: "procedural",
      title: "Sandbox policy",
      body: "Only sandbox, retrieve, memory, orbita_status. No shell. Destroy worker after result.",
      createdAt: Date.now() - 86400000,
    },
    {
      id: "proc-escalate",
      kind: "procedural",
      title: "Escalation rules",
      body: "Escalate when confidence < 0.55, governed research, or verification fails.",
      createdAt: Date.now() - 86400000,
    },
  ];
}

export function getSystemStatusHandler() {
  const stats = corpusStats();
  return {
    ai: aiAvailable(),
    student: "grok-4.5 · worker",
    teacher: "grok-4.5 · supervisor",
    retrieval: `${stats.documents} docs · ${stats.tokens} tokens · BM25+rerank`,
    sandbox: "policy engine · isolated python",
    orbita: "SHA-256 freeze · independent eval",
    desktop: "XFCE · noVNC · Tailscale-only",
  };
}

export async function executeRun(data: {
  request: string;
  mode: AgentMode;
  history: { role: string; content: string }[];
  desktop?: DeskSnapshot;
}): Promise<RunTrace> {
    const started = Date.now();
    const steps: RunStep[] = [];
    const toolTrace: ToolResult[] = [];
    const memory = seedMemory();
    let desk = data.desktop ?? initialDesktop();
    const id = crypto.randomUUID();

    const t0 = Date.now();
    const retrieved = retrieve(data.request, 5);
    steps.push(
      step("retrieve", "Language tower", `Top ${retrieved.length} passages after BM25 + rerank`, {
        latencyMs: Date.now() - t0,
        data: {
          ids: retrieved.map((d) => d.id),
          titles: retrieved.map((d) => d.title),
        },
      }),
    );

    if (!aiAvailable()) {
      if (data.mode === "governed") {
        return localGoverned({
          id,
          started,
          request: data.request,
          mode: data.mode,
          retrieved,
          steps,
          toolTrace,
          memory,
          desk,
        });
      }
      return offlineRun({
        id,
        started,
        request: data.request,
        mode: data.mode,
        retrieved,
        steps,
        toolTrace,
        memory,
        reason: "Local worker · language tower + sandbox",
        desk,
      });
    }

    if (data.mode === "governed") {
      return runGoverned({
        id,
        started,
        request: data.request,
        mode: data.mode,
        retrieved,
        steps,
        toolTrace,
        memory,
        desk,
      });
    }

    steps.push(
      step("route", "Model router", "Student first · teacher on fail / low confidence", {
        data: { choice: "student" },
      }),
    );

    const historyMsgs = data.history.map((h) => ({
      role: h.role as "user" | "assistant",
      content: h.content,
    }));

    const baseMsgs = [
      { role: "system" as const, content: STUDENT_SYS },
      ...historyMsgs,
      {
        role: "user" as const,
        content: `Request:\n${data.request}\n\nRetrieved context:\n${docsBlock(retrieved)}`,
      },
    ];

    let apiCalls = 0;
    let raw = await studentChat(baseMsgs);
    apiCalls += 1;
    if (!raw.ok) {
      return offlineRun({
        id,
        started,
        request: data.request,
        mode: data.mode,
        retrieved,
        steps,
        toolTrace,
        memory,
        reason: "Retrieval + sandbox worker · generative model skipped",
        desk,
      });
    }

    let decision = parseDecision(raw.text);
    if (!decision) {
      decision = {
        thought: "Could not parse structured output",
        confidence: 0.2,
        action: "escalate",
        answer: raw.text.slice(0, 1200),
      };
    }

    steps.push(
      step("reason", "Student reason", decision.thought || "Structured action", {
        model: "student",
        data: { action: decision.action, confidence: decision.confidence },
      }),
    );

    let rounds = 0;
    while (decision.action === "tool" && decision.tool && rounds < 2 && apiCalls < 3) {
      const tTool = Date.now();
      const executed = await executeTool(decision.tool, memory, desk);
      desk = executed.desk;
      const result = executed.result;
      toolTrace.push(result);
      if (decision.tool.name === "memory_write") {
        memory.push({
          id: `work-${memory.length}`,
          kind: "working",
          title: decision.tool.arguments.title ?? "note",
          body: decision.tool.arguments.body ?? "",
          createdAt: Date.now(),
        });
      }
      steps.push(
        step("tool", `Sandbox / tool · ${decision.tool.name}`, result.output.slice(0, 280), {
          latencyMs: Date.now() - tTool,
          data: { ok: result.ok, name: result.name },
        }),
      );
      raw = await studentChat([
        ...baseMsgs,
        {
          role: "assistant",
          content: JSON.stringify(decision),
        },
        {
          role: "user",
          content: `Tool ${result.name} ${result.ok ? "ok" : "failed"}:\n${result.output}\nContinue. JSON only.`,
        },
      ]);
      apiCalls += 1;
      if (!raw.ok) break;
      decision = parseDecision(raw.text) ?? {
        thought: "parse fail after tool",
        confidence: 0.25,
        action: "escalate",
      };
      rounds += 1;
      steps.push(
        step("reason", "Student continue", decision.thought || decision.action, {
          model: "student",
          data: { action: decision.action, confidence: decision.confidence },
        }),
      );
    }

    if (
      decision.action !== "tool" &&
      (!decision.answer || decision.answer.trim().length < 8)
    ) {
      const lastOk = [...toolTrace].reverse().find((t) => t.ok);
      if (lastOk) {
        decision = {
          ...decision,
          action: "answer",
          answer: lastOk.output,
          confidence: Math.max(decision.confidence, 0.7),
        };
      }
    }

    const verdict = verify(data.request, decision, toolTrace);
    steps.push(
      step("verify", "Verifier", verdict.reason, {
        data: { pass: verdict.pass, confidence: decision.confidence },
      }),
    );

    const shouldEscalate =
      decision.action === "escalate" || !verdict.pass || decision.confidence < 0.55;

    if (shouldEscalate && apiCalls < 3) {
      steps.push(
        step("escalate", "Escalate to teacher", "Student failed verification or requested supervision", {
          model: "teacher",
        }),
      );
      const tTeach = await teacherChat([
        { role: "system", content: TEACHER_SYS },
        {
          role: "user",
          content: `Original request:\n${data.request}\n\nRetrieved:\n${docsBlock(retrieved)}\n\nStudent attempt:\n${JSON.stringify(decision)}\n\nTool trace:\n${toolTrace.map((t) => t.name + ": " + t.output).join("\n")}\n\nVerifier: ${verdict.reason}\nProduce the corrected final answer as JSON with action=answer.`,
        },
      ]);
      apiCalls += 1;
      if (!tTeach.ok) {
        return offlineRun({
          id,
          started,
          request: data.request,
          mode: data.mode,
          retrieved,
          steps,
          toolTrace,
          memory,
          reason: "Teacher skipped · answering from tower and sandbox",
          desk,
        });
      }
      const teacherDec = parseDecision(tTeach.text);
      const answer = teacherDec?.answer || tTeach.text;
      const training: TrainingRecord = {
        id: `tr-${id.slice(0, 8)}`,
        prompt: data.request,
        studentAttempt: decision.answer || decision.thought || JSON.stringify(decision),
        teacherAnswer: answer,
        verification: "fail",
        createdAt: Date.now(),
      };
      steps.push(
        step("answer", "Teacher answer", "Supervised completion", {
          model: "teacher",
        }),
      );
      return {
        id,
        createdAt: started,
        request: data.request,
        mode: data.mode,
        status: "ok",
        escalated: true,
        modelPath: "student→teacher",
        answer,
        citations: teacherDec?.citations ?? retrieved.map((d) => d.id).slice(0, 3),
        confidence: teacherDec?.confidence ?? 0.8,
        steps,
        retrieved,
        toolTrace,
        training,
        desktop: desk,
        tokensHint: `${apiCalls} model calls`,
        totalMs: Date.now() - started,
      };
    }

    steps.push(step("answer", "Student answer", "Passed verification", { model: "student" }));
    return {
      id,
      createdAt: started,
      request: data.request,
      mode: data.mode,
      status: "ok",
      escalated: false,
      modelPath: "student",
      answer: decision.answer || "No answer.",
      citations: decision.citations ?? retrieved.map((d) => d.id).slice(0, 3),
      confidence: decision.confidence,
      steps,
      retrieved,
      toolTrace,
      desktop: desk,
      tokensHint: `${apiCalls} model calls`,
      totalMs: Date.now() - started,
    };
}

async function runGoverned(opts: {
  id: string;
  started: number;
  request: string;
  mode: AgentMode;
  retrieved: RetrievedDoc[];
  steps: RunStep[];
  toolTrace: ToolResult[];
  memory: MemoryItem[];
  desk: DeskSnapshot;
}): Promise<RunTrace> {
  const { id, started, request, retrieved, steps, toolTrace, memory } = opts;
  let desk = opts.desk;
  steps.push(
    step("route", "Model router", "Governed path · teacher proposes a frozen plan", {
      data: { choice: "teacher" },
    }),
  );
  steps.push(
    step("orbita", "Orbita case", "Opened governed case from request + tower context"),
  );

  const planRes = await teacherChat(
    [
      { role: "system", content: TEACHER_SYS },
      {
        role: "user",
        content: `Create a governed experiment/analysis plan for:\n${request}\n\nCase context:\n${docsBlock(retrieved)}\n\nJSON with thought, plan (full text), answer (brief summary of what will be tested), confidence, citations.`,
      },
    ],
    { maxTokens: 900, json: true },
  );
  if (!planRes.ok) {
    return localGoverned({
      id,
      started,
      request,
      mode: opts.mode,
      retrieved,
      steps,
      toolTrace,
      memory,
      desk,
    });
  }
  const planned = parseDecision(planRes.text);
  const planText =
    extractField(planRes.text, "plan") ||
    planned?.answer ||
    planRes.text;
  let record = compilePlan(request, planText);
  steps.push(
    step("orbita", "Compile + freeze", `SHA-256 ${record.planHash.slice(0, 16)}…`, {
      data: { planHash: record.planHash, caseId: record.caseId },
    }),
  );
  record = approvePlan(record);
  steps.push(step("orbita", "Approve plan", "Approval boundary crossed · plan is now immutable"));

  const sandboxSnippet = /sandbox|python|compute|calculate|FV|precision/i.test(planText);
  if (sandboxSnippet) {
    const code = extractPython(planText) ?? "print(round(10000 * (1.07 ** 12), 2))";
    const executed = await executeTool(
      { name: "sandbox", arguments: { code } },
      memory,
      desk,
    );
    desk = executed.desk;
    const result = executed.result;
    toolTrace.push(result);
    steps.push(
      step("tool", "Sandbox execution", result.output.slice(0, 280), {
        data: { ok: result.ok },
      }),
    );
  }

  const evalRes = await teacherChat(
    [
      { role: "system", content: TEACHER_SYS },
      {
        role: "user",
        content: `Evaluate this FROZEN plan. You may not change the plan.
PLAN HASH: ${record.planHash}
PLAN:\n${record.plan}
TOOL TRACE:\n${toolTrace.map((t) => t.output).join("\n") || "(none)"}
ORIGINAL QUESTION:\n${request}
JSON with thought, answer (the governed result), evaluation_pass (boolean), evaluation_notes, confidence, citations.`,
      },
    ],
    { maxTokens: 700, json: true },
  );
  if (!evalRes.ok) {
    return localGoverned({
      id,
      started,
      request,
      mode: opts.mode,
      retrieved,
      steps,
      toolTrace,
      memory,
      existingPlan: record.plan,
      desk,
    });
  }
  const evaluated = parseDecision(evalRes.text);
  const evalPass = extractBool(evalRes.text, "evaluation_pass") ?? true;
  const evalNotes =
    extractField(evalRes.text, "evaluation_notes") ||
    evaluated?.thought ||
    "Independent evaluation recorded.";
  record = attachDiscovery(record, evaluated?.answer || evalRes.text.slice(0, 1500));
  record = evaluateRecord(record, { pass: evalPass, notes: evalNotes });
  steps.push(
    step("verify", "Independent evaluation", evalNotes.slice(0, 220), {
      data: { pass: evalPass, planHash: record.planHash },
    }),
  );
  steps.push(
    step("answer", "Governed result", "Frozen plan + evaluation recorded", {
      model: "teacher",
    }),
  );

  const answer =
    evaluated?.answer ||
    `Governed result for ${record.caseId}. Plan hash ${record.planHash.slice(0, 12)}. ${evalNotes}`;

  return {
    id,
    createdAt: started,
    request,
    mode: opts.mode,
    status: "ok",
    escalated: true,
    modelPath: "teacher",
    answer,
    citations: evaluated?.citations ?? retrieved.map((d) => d.id).slice(0, 3),
    confidence: evaluated?.confidence ?? 0.82,
    steps,
    retrieved,
    toolTrace,
    orbita: record,
    desktop: desk,
    tokensHint: "2 teacher calls",
    totalMs: Date.now() - started,
  };
}

function inferPython(request: string): string | null {
  const money = request.match(/\$\s*([\d,]+)/);
  const rate = request.match(/(\d+(?:\.\d+)?)\s*%/);
  const years = request.match(/(\d+)\s*years?/);
  if (money && rate && years) {
    const pv = money[1].replace(/,/g, "");
    return `print(round(${pv} * (1 + ${Number(rate[1]) / 100}) ** ${years[1]}, 2))`;
  }
  return null;
}

function answerFromTower(request: string, docs: RetrievedDoc[], tools: ToolResult[]): string {
  const deskOut = tools.find((t) => t.name === "desktop");
  if (deskOut) {
    const cite = docs[0]
      ? `\n\n${docs[0].title} — ${docs[0].text.slice(0, 280)}`
      : "";
    return `${deskOut.output}${cite}`.trim();
  }
  const calc = tools.find((t) => t.name === "sandbox" && t.ok);
  if (calc) {
    return `Sandbox result: ${calc.output}\n\n${docs[0] ? docs[0].title + " — " + docs[0].text.slice(0, 360) : ""}`.trim();
  }
  if (!docs.length) {
    return `No passages matched “${request.slice(0, 80)}”, and the generative worker is offline.`;
  }
  const body = docs
    .slice(0, 3)
    .map((d, i) => `${i + 1}. ${d.title}\n${d.text.split(/(?<=\.)\s+/).slice(0, 2).join(" ")}`)
    .join("\n\n");
  return body;
}

async function maybeLocalTools(
  request: string,
  memory: MemoryItem[],
  desk: DeskSnapshot,
): Promise<{ tools: ToolResult[]; desk: DeskSnapshot }> {
  const tools: ToolResult[] = [];
  const code = inferPython(request);
  if (code) {
    const executed = await executeTool({ name: "sandbox", arguments: { code } }, memory, desk);
    desk = executed.desk;
    tools.push(executed.result);
  }
  if (/pocketdesktop|screenshot|launch chromium|desktop status|novnc|xfce/i.test(request)) {
    if (desk.status !== "running") {
      const booted = await executeTool(
        { name: "desktop", arguments: { action: "start" } },
        memory,
        desk,
      );
      desk = booted.desk;
      tools.push(booted.result);
    }
    const action = /screenshot/i.test(request)
      ? "screenshot"
      : /launch/i.test(request)
        ? "launch"
        : "status";
    const executed = await executeTool(
      {
        name: "desktop",
        arguments: { action, app: "chromium" },
      },
      memory,
      desk,
    );
    desk = executed.desk;
    tools.push(executed.result);
  }
  return { tools, desk };
}

async function offlineRun(opts: {
  id: string;
  started: number;
  request: string;
  mode: AgentMode;
  retrieved: RetrievedDoc[];
  steps: RunStep[];
  toolTrace: ToolResult[];
  memory: MemoryItem[];
  reason: string;
  desk: DeskSnapshot;
}): Promise<RunTrace> {
  const { id, started, request, retrieved, steps, toolTrace, memory, reason } = opts;
  let desk = opts.desk;
  if (!steps.some((s) => s.kind === "route")) {
    steps.push(
      step("route", "Model router", reason, { data: { choice: "student" } }),
    );
  }
  const extra = await maybeLocalTools(request, memory, desk);
  desk = extra.desk;
  for (const t of extra.tools) {
    toolTrace.push(t);
    steps.push(
      step("tool", `Sandbox / tool · ${t.name}`, t.output.slice(0, 280), {
        data: { ok: t.ok, name: t.name },
      }),
    );
  }
  const answer = answerFromTower(request, retrieved, toolTrace);
  steps.push(
    step("verify", "Verifier", "Tower passages present; generative worker skipped"),
  );
  steps.push(step("answer", "Tower answer", reason, { model: "student" }));
  return {
    id,
    createdAt: started,
    request,
    mode: opts.mode,
    status: "ok",
    escalated: false,
    modelPath: "student",
    answer,
    citations: retrieved.map((d) => d.id).slice(0, 4),
    confidence: retrieved.length ? 0.62 : 0.3,
    steps,
    retrieved,
    toolTrace,
    desktop: desk,
    tokensHint: "0 model calls",
    totalMs: Date.now() - started,
  };
}

async function localGoverned(opts: {
  id: string;
  started: number;
  request: string;
  mode: AgentMode;
  retrieved: RetrievedDoc[];
  steps: RunStep[];
  toolTrace: ToolResult[];
  memory: MemoryItem[];
  existingPlan?: string;
  desk: DeskSnapshot;
}): Promise<RunTrace> {
  const { id, started, request, retrieved, steps, toolTrace, memory } = opts;
  let desk = opts.desk;
  if (!steps.some((s) => s.kind === "route")) {
    steps.push(
      step("route", "Model router", "Governed path · local freeze (teacher offline)", {
        data: { choice: "teacher" },
      }),
    );
    steps.push(step("orbita", "Orbita case", "Opened governed case from request + tower context"));
  }
  const plan =
    opts.existingPlan ??
    `Hypothesis: ${request}
Method: Retrieve from the language tower, freeze this plan, run numeric checks in the sandbox if present, and score the answer against retrieved ids ${retrieved.map((d) => d.id).join(", ") || "(none)"}.
Success: A concrete cited answer, or a numeric result that matches the sandbox.
Falsification: Empty answer, denied tool, or no supporting passage.
Sandbox: numeric evaluation only when the question contains a calculation.`;
  let record = compilePlan(request, plan);
  steps.push(
    step("orbita", "Compile + freeze", `SHA-256 ${record.planHash.slice(0, 16)}…`, {
      data: { planHash: record.planHash, caseId: record.caseId },
    }),
  );
  record = approvePlan(record);
  steps.push(step("orbita", "Approve plan", "Approval boundary crossed · plan is now immutable"));
  const extra = await maybeLocalTools(request, memory, desk);
  desk = extra.desk;
  for (const t of extra.tools) {
    toolTrace.push(t);
    steps.push(
      step("tool", "Sandbox execution", t.output.slice(0, 280), { data: { ok: t.ok } }),
    );
  }
  const discovery = answerFromTower(request, retrieved, toolTrace);
  const pass = discovery.length > 40 && (toolTrace.length === 0 || toolTrace.some((t) => t.ok));
  record = attachDiscovery(record, discovery);
  record = evaluateRecord(record, {
    pass,
    notes: pass
      ? "Independent eval against frozen plan: supporting passages (and sandbox, if used) match success criteria."
      : "Independent eval: insufficient evidence. Record kept as a negative governed result.",
  });
  steps.push(
    step("verify", "Independent evaluation", record.evaluation?.notes ?? "", {
      data: { pass, planHash: record.planHash },
    }),
  );
  steps.push(
    step("answer", "Governed result", "Frozen plan + evaluation recorded", { model: "teacher" }),
  );
  return {
    id,
    createdAt: started,
    request,
    mode: opts.mode,
    status: "ok",
    escalated: true,
    modelPath: "teacher",
    answer: `${discovery}\n\nCase ${record.caseId}. Plan hash ${record.planHash.slice(0, 16)}. ${record.evaluation?.notes}`,
    citations: retrieved.map((d) => d.id).slice(0, 4),
    confidence: 0.7,
    steps,
    retrieved,
    toolTrace,
    orbita: record,
    desktop: desk,
    tokensHint: "0 model calls",
    totalMs: Date.now() - started,
  };
}

function extractField(raw: string, key: string): string | undefined {
  try {
    const start = raw.indexOf("{");
    const end = raw.lastIndexOf("}");
    if (start < 0 || end <= start) return undefined;
    const obj = JSON.parse(raw.slice(start, end + 1)) as Record<string, unknown>;
    const v = obj[key];
    return typeof v === "string" ? v : undefined;
  } catch {
    return undefined;
  }
}

function extractBool(raw: string, key: string): boolean | undefined {
  try {
    const start = raw.indexOf("{");
    const end = raw.lastIndexOf("}");
    if (start < 0 || end <= start) return undefined;
    const obj = JSON.parse(raw.slice(start, end + 1)) as Record<string, unknown>;
    const v = obj[key];
    if (typeof v === "boolean") return v;
    return undefined;
  } catch {
    return undefined;
  }
}

function extractPython(plan: string): string | null {
  const m = plan.match(/```(?:python)?\n([\s\S]*?)```/);
  if (m?.[1]) return m[1].trim();
  return null;
}

function errorTrace(
  id: string,
  started: number,
  data: { request: string; mode: AgentMode },
  retrieved: RetrievedDoc[],
  steps: RunStep[],
  toolTrace: ToolResult[],
  error: string,
): RunTrace {
  steps.push(step("answer", "Error", error));
  return {
    id,
    createdAt: started,
    request: data.request,
    mode: data.mode,
    status: "error",
    error,
    escalated: false,
    modelPath: "student",
    answer: error,
    citations: [],
    confidence: 0,
    steps,
    retrieved,
    toolTrace,
    tokensHint: "error",
    totalMs: Date.now() - started,
  };
}

export function listCorpusHandler() {
  return CORPUS.map((d) => ({
    id: d.id,
    title: d.title,
    tags: d.tags,
    excerpt: d.text.slice(0, 180),
  }));
}
