export type CorpusDoc = {
  id: string;
  title: string;
  tags: string[];
  text: string;
};

export const CORPUS: CorpusDoc[] = [
  {
    id: "doc-layers",
    title: "Orbita is an agent system, not a model",
    tags: ["architecture", "orchestrator", "vllm"],
    text: `The cleanest version of Orbita is not one giant model on one VM. The VM hosts an agent system with separate inference, retrieval, governance, and execution layers. LLM/SLM is the actual model. vLLM is software for running and serving the model. The teacher is a stronger model used for difficult reasoning, supervision, and creating training data. The language tower is the embedding, retrieval, and reranking subsystem. Orbita/HodgeForm is the governed reasoning and experimentation layer. The agent is the software loop connecting all of them. vLLM exposes an OpenAI-compatible HTTP interface, structured outputs, and tool calling, so it sits behind the agent controller rather than containing the agent.`,
  },
  {
    id: "doc-two-models",
    title: "Teacher and student routing",
    tags: ["teacher", "student", "routing", "cost"],
    text: `Orbita uses two models. The student or worker is a 3B–14B-class open model served locally through vLLM. It classifies requests, retrieves context, extracts structured data, decides ordinary tool calls, summarizes tool outputs, and handles simple coding. The teacher is a large high-quality LLM, initially API-based. The teacher is called when confidence is below threshold, task complexity is high, an Orbita plan is needed, or verification failed. This drastically reduces inference expense. Later, the teacher's successful outputs become data for improving the student. Never put the agent loop inside vLLM — the controller treats vLLM as POST /v1/chat/completions, just like another model provider.`,
  },
  {
    id: "doc-language-tower",
    title: "Language tower: embed, retrieve, rerank",
    tags: ["retrieval", "rag", "embeddings", "rerank"],
    text: `The language tower is a separate semantic understanding and retrieval system. Incoming request → embedding model → vector search → top 30 documents → reranker → top 5 documents → SLM. This avoids wasting generative-model tokens trying to remember everything. vLLM can serve embedding, scoring, and reranking models, including an OpenAI-compatible /v1/embeddings endpoint. A typical split is :8000 generative SLM, :8001 embedding model, :8002 reranker. In this control plane, retrieval is lexical BM25-style over the governed corpus plus a rerank by title and tag overlap, then the student sees only the top passages.`,
  },
  {
    id: "doc-orbita",
    title: "Orbita / HodgeForm as scientific governor",
    tags: ["orbita", "hodgeform", "governance", "plan"],
    text: `Ordinary agent thoughts should not all run through Orbita. Fast agent loop: User → Retrieve → SLM → Tool call → Verify → Answer, in milliseconds to seconds. Governed reasoning loop is for research, experimentation, model improvement, or claims that matter: Question → Orbita case → case context → teacher proposes analysis plan → submit/compile plan → frozen plan + SHA-256 → approval → run discovery → candidate result → freeze experiment → sandbox execution → independent evaluation → record governed result. That creates an immutable boundary between "the AI proposed something" and "we actually tested that thing."`,
  },
  {
    id: "doc-orbita-primitives",
    title: "Orbita interface primitives",
    tags: ["orbita", "api", "plan", "hash"],
    text: `The Orbita/HodgeForm interface exposes: orbita_case_context, orbita_compile_plan or orbita_submit_plan, orbita_get_plan, orbita_approve_plan, orbita_run_discovery, orbita_freeze_external_experiment, orbita_get_governed_improvement, orbita_record_governed_improvement_evaluation. A frozen plan is hashed with SHA-256. After freeze, the plan text is immutable. Discovery must execute the frozen plan, not a later rewritten one. Evaluation is independent of the proposing model.`,
  },
  {
    id: "doc-improvement-loop",
    title: "Teacher/student improvement loop",
    tags: ["training", "lora", "distillation", "traces"],
    text: `The killer feature is a teacher/student improvement loop. When the SLM fails a task: verifier says FAIL → teacher solves it → Orbita creates a bounded evaluation → teacher solution is tested → store prompt, retrieval context, student attempt, teacher answer, tool trace, verification result, Orbita plan hash, and experiment result. After enough records, production traffic hits the student; failures go to the teacher, then Orbita verification, then the training DB, then LoRA / fine-tune, then an improved student. vLLM can serve LoRA adapters over a base model so specialized students (research, coding, finance, data-analysis) do not require separate foundation models. The worker is never allowed to arbitrarily rewrite itself.`,
  },
  {
    id: "doc-sandbox",
    title: "Keep execution outside the model process",
    tags: ["sandbox", "tools", "policy", "security"],
    text: `Never give the LLM unrestricted Linux shell access. The model emits a structured action such as { "tool": "python", "arguments": {...} }. An agent policy engine validates the tool name and schema, then an isolated worker or container executes it and returns a result. Allowed tools are an explicit set: sandbox/python, search/retrieve, read-only database, Orbita client. Ephemeral workers are preferred: controller → job queue → temporary container → execute → capture artifact → destroy. Not LLM → sudo bash.`,
  },
  {
    id: "doc-memory",
    title: "Explicit agent memory, not just the prompt",
    tags: ["memory", "postgres", "vector", "state"],
    text: `Do not put all memory into prompts. Working memory is the current conversation or task. Semantic memory is embeddings and knowledge. Episodic memory is previous agent runs. Procedural memory is tools, skills, and instructions. Experimental memory is Orbita plans and results. Training memory is teacher/student traces. Storage: Postgres for users, sessions, runs, messages, tool_calls, evaluations, model_versions, experiment_refs. Vector DB for documents, memories, successful traces. Object storage for datasets, source files, generated artifacts, and checkpoints.`,
  },
  {
    id: "doc-agent-loop",
    title: "The fast agent loop",
    tags: ["loop", "verify", "tools"],
    text: `The actual agent loop stays small: 1. Understand and retrieve via the language tower. 2. Decide which model should handle it. 3. Ask the model for a structured action with tool schemas. 4. Execute tools while the model keeps calling them. 5. Verify the answer against the request. 6. Escalate difficult failures to the teacher. If the request requires governed research, create or load an Orbita case, have the teacher propose a plan from case context, freeze the plan, review/approve, then run discovery.`,
  },
  {
    id: "doc-build-order",
    title: "Recommended build order",
    tags: ["mvp", "phases", "vllm"],
    text: `Do not start with model training. Phase 1: Linux GPU VM + vLLM student + FastAPI orchestrator + 5–10 controlled tools, until one agent reliably executes structured tasks. Phase 2: embedding model, pgvector, reranker, RAG. Phase 3: teacher routing and trace collection. Phase 4: Orbita/HodgeForm frozen plan, controlled experiment, evaluation. Phase 5: learning loop — production failures → teacher correction → Orbita falsification/eval → validated dataset → LoRA / distillation → new student → A/B evaluation. Kubernetes is not required for the MVP.`,
  },
  {
    id: "doc-hodgeform",
    title: "HodgeForm and falsifiable evaluation",
    tags: ["hodgeform", "science", "evaluation"],
    text: `HodgeForm is the mathematical and experimental posture behind Orbita: claims are treated as forms that must be frozen before they are tested. A proposal is not a result. A result is not governed until an independent evaluation has run against a hashed plan. Falsification is first-class: an experiment that fails its success criteria is a valid governed record, and is often more useful for student training than a vague success. This is what ordinary agents lack — they rewrite the plan while executing it, so you cannot tell whether the idea worked.`,
  },
  {
    id: "doc-compound",
    title: "Compound growth formula",
    tags: ["math", "finance", "sandbox"],
    text: `Future value with compound interest is FV = PV * (1 + r)^n where PV is present value, r is the rate per period as a decimal, and n is the number of periods. Example: $10,000 at 7% for 12 years is 10000 * (1.07 ** 12). Use the sandbox for the numeric evaluation rather than estimating. Annual compounding is assumed unless stated otherwise.`,
  },
  {
    id: "doc-vllm",
    title: "vLLM serving notes",
    tags: ["vllm", "inference", "lora"],
    text: `vLLM currently exposes an OpenAI-compatible HTTP interface, structured outputs, and tool calling. Structured output is particularly useful because the agent can require JSON schemas rather than parsing arbitrary model prose. vLLM also supports serving LoRA adapters, including different adapters over one base model. The controller should call it with an OpenAI client pointed at http://vllm:8000/v1. In this preview, the student and teacher are both served through the xAI API with different budgets, prompts, and routing rules, standing in for local vLLM plus an API teacher.`,
  },
  {
    id: "doc-services",
    title: "MVP service layout on one GPU VM",
    tags: ["infra", "docker", "postgres"],
    text: `MVP host: Ubuntu 24.04, NVIDIA GPU, Docker, NVIDIA Container Toolkit. Services: FastAPI agent/controller, vLLM SLM inference, Postgres for agent state, pgvector or Qdrant for semantic memory, Redis for queues and cache, MinIO/S3 for artifacts, Orbita/HodgeForm for governed analysis, Docker sandbox workers. Data directories: postgres, vector-store, object-store, logs. Separate machines later; Kubernetes is optional after the loop works.`,
  },
  {
    id: "doc-pocketdesktop",
    title: "PocketDesktop: a desktop target, not a root shell",
    tags: ["desktop", "pocketdesktop", "novnc", "tailscale", "xfce"],
    text: `PocketDesktop Linux v0.1.0 gives Orbita a private Ubuntu 24.04 XFCE desktop alongside PocketDroid. Default VM: project pocketdroid, name pocketdesktop, zone us-east4-b, machine e2-standard-2, 35 GB balanced disk. Stack: Xvfb 1440×900, XFCE, x11vnc on localhost:5900, noVNC/websockify on 127.0.0.1:6080, Tailscale-only HTTPS serve, Chromium autostart, 20-minute idle auto-shutdown. The agent must not get unrestricted root. The narrow API is screenshot, mouse click, keyboard type, and approved app launches (chromium, files, terminal, calculator), with every action logged. sudo, ssh, rm -rf, and shutdown are policy-denied. Operator VM controls (start/stop/status) live outside the model process.`,
  },
];
