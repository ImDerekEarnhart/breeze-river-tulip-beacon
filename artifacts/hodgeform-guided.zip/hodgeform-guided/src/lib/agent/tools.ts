import { retrieve } from "./language-tower";
import { runSandbox } from "./sandbox";
import { applyDesk, initialDesktop, type DeskSnapshot } from "../desktop";
import type { MemoryItem, ToolCall, ToolResult } from "./types";

export const TOOL_SCHEMAS = [
  {
    name: "sandbox",
    description:
      "Run short Python in an isolated worker. Use for arithmetic, lists, and numeric checks. No files, no network, no OS.",
    arguments: { code: "python source" },
  },
  {
    name: "retrieve",
    description: "Search the language tower / semantic memory for more passages.",
    arguments: { query: "search query" },
  },
  {
    name: "memory_read",
    description: "Read a working or episodic memory item by id or keyword.",
    arguments: { query: "id or keyword" },
  },
  {
    name: "memory_write",
    description: "Write a short note into working memory for this run.",
    arguments: { title: "title", body: "body" },
  },
  {
    name: "orbita_status",
    description: "Inspect current governed-experiment primitives and frozen-plan rules.",
    arguments: { topic: "optional focus" },
  },
  {
    name: "desktop",
    description:
      "SIMULATED PocketDesktop. action=status|start|stop|screenshot|click|type|launch. Not a real VM. Approved apps: chromium, files, terminal, calculator. No root.",
    arguments: {
      action: "status|start|stop|screenshot|click|type|launch",
      x: "px",
      y: "px",
      text: "keys",
      app: "allow-listed app",
    },
  },
] as const;

const ALLOWED = new Set(TOOL_SCHEMAS.map((t) => t.name));

export async function executeTool(
  call: ToolCall,
  memory: MemoryItem[],
  desk: DeskSnapshot = initialDesktop(),
): Promise<{ result: ToolResult; desk: DeskSnapshot }> {
  if (!ALLOWED.has(call.name)) {
    return {
      result: { name: call.name, ok: false, output: "ToolDenied: not in ALLOWED_TOOLS" },
      desk,
    };
  }

  if (call.name === "sandbox") {
    const code = call.arguments.code ?? call.arguments.source ?? "";
    if (!code.trim()) {
      return { result: { name: "sandbox", ok: false, output: "Missing code" }, desk };
    }
    const ran = await runSandbox(code);
    return { result: { name: "sandbox", ok: ran.ok, output: ran.output }, desk };
  }

  if (call.name === "retrieve") {
    const query = call.arguments.query ?? "";
    const docs = retrieve(query, 4);
    return {
      result: {
        name: "retrieve",
        ok: true,
        output: docs
          .map((d) => `[${d.id}] ${d.title}\n${d.text.slice(0, 420)}`)
          .join("\n\n"),
      },
      desk,
    };
  }

  if (call.name === "memory_read") {
    const q = (call.arguments.query ?? "").toLowerCase();
    const hits = memory.filter(
      (m) =>
        m.id.includes(q) ||
        m.title.toLowerCase().includes(q) ||
        m.body.toLowerCase().includes(q) ||
        m.kind.includes(q),
    );
    return {
      result: {
        name: "memory_read",
        ok: true,
        output: hits.length
          ? hits
              .slice(0, 6)
              .map((m) => `[${m.kind}/${m.id}] ${m.title}: ${m.body}`)
              .join("\n")
          : "No matching memory.",
      },
      desk,
    };
  }

  if (call.name === "memory_write") {
    return {
      result: {
        name: "memory_write",
        ok: true,
        output: `stored:${call.arguments.title ?? "note"}`,
      },
      desk,
    };
  }

  if (call.name === "orbita_status") {
    return {
      result: {
        name: "orbita_status",
        ok: true,
        output:
          "Primitives: case_context, compile_plan, submit_plan, get_plan, approve_plan, run_discovery, freeze_external_experiment, record_evaluation. Frozen plans are SHA-256 hashed and immutable. Ordinary chat should not enter this path.",
      },
      desk,
    };
  }

  if (call.name === "desktop") {
    const action = (call.arguments.action ?? "status").toLowerCase();
    let current = desk;
    const notes: string[] = [];
    if (
      current.status !== "running" &&
      (action === "screenshot" || action === "click" || action === "type" || action === "launch")
    ) {
      const booted = applyDesk(current, { action: "start" });
      current = booted.snapshot;
      notes.push(booted.output.split("\n")[0] ?? "started");
    }
    const applied = applyDesk(current, {
      action,
      x: call.arguments.x ? Number(call.arguments.x) : undefined,
      y: call.arguments.y ? Number(call.arguments.y) : undefined,
      text: call.arguments.text,
      app: call.arguments.app,
    });
    const output = notes.length ? `${notes.join("\n")}\n${applied.output}` : applied.output;
    return {
      result: { name: "desktop", ok: applied.ok, output },
      desk: applied.snapshot,
    };
  }

  return {
    result: { name: call.name, ok: false, output: "Unknown tool" },
    desk,
  };
}
