import type { DeskSnapshot } from "../desktop";

export type AgentMode = "fast" | "governed";
export type ModelRole = "student" | "teacher";
export type StepKind =
  | "retrieve"
  | "route"
  | "reason"
  | "tool"
  | "verify"
  | "escalate"
  | "orbita"
  | "answer";

export type RetrievedDoc = {
  id: string;
  title: string;
  text: string;
  score: number;
  tags: string[];
};

export type ToolName =
  | "sandbox"
  | "retrieve"
  | "memory_read"
  | "memory_write"
  | "orbita_status"
  | "desktop";

export type ToolCall = {
  name: ToolName;
  arguments: Record<string, string>;
};

export type ToolResult = {
  name: ToolName;
  ok: boolean;
  output: string;
};

export type AgentDecision = {
  thought: string;
  confidence: number;
  action: "answer" | "tool" | "escalate";
  tool?: ToolCall;
  answer?: string;
  citations?: string[];
};

export type StepData = {
  ids?: string[];
  titles?: string[];
  choice?: string;
  action?: string;
  confidence?: number;
  pass?: boolean;
  ok?: boolean;
  name?: string;
  planHash?: string;
  caseId?: string;
  modelId?: string;
  provider?: string;
};

export type RunStep = {
  id: string;
  kind: StepKind;
  title: string;
  detail: string;
  model?: ModelRole;
  latencyMs: number;
  data?: StepData;
};

export type RunTrace = {
  id: string;
  createdAt: number;
  request: string;
  mode: AgentMode;
  status: "ok" | "error";
  error?: string;
  escalated: boolean;
  modelPath: "student" | "teacher" | "student→teacher";
  answer: string;
  citations: string[];
  confidence: number;
  steps: RunStep[];
  retrieved: RetrievedDoc[];
  toolTrace: ToolResult[];
  orbita?: OrbitaRecord;
  training?: TrainingRecord;
  desktop?: DeskSnapshot;
  tokensHint: string;
  totalMs: number;
  studentModel?: string;
  teacherModel?: string;
  providerCalls?: ProviderCall[];
  hodgeform?: HodgeformMeta;
};

export type ProviderCall = {
  role: ModelRole;
  provider: string;
  model: string;
  ok: boolean;
  latencyMs: number;
};

export type HodgeformMeta = {
  connected: boolean;
  status: string;
  host: string;
  tools: string[];
  error?: string;
  authMode?: string;
};

export type TrainingRecord = {
  id: string;
  prompt: string;
  studentAttempt: string;
  teacherAnswer: string;
  verification: "fail" | "pass";
  planHash?: string;
  createdAt: number;
};

export type OrbitaRecord = {
  caseId: string;
  question: string;
  plan: string;
  planHash: string;
  status:
    | "compiled"
    | "frozen"
    | "approved"
    | "discovery"
    | "evaluated";
  discovery?: string;
  evaluation?: {
    pass: boolean;
    notes: string;
  };
  createdAt: number;
};

export type MemoryKind =
  | "working"
  | "semantic"
  | "episodic"
  | "procedural"
  | "experimental"
  | "training";

export type MemoryItem = {
  id: string;
  kind: MemoryKind;
  title: string;
  body: string;
  createdAt: number;
};
